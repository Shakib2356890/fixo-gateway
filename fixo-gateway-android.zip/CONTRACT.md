# Server ↔ App contract — Fixo self-hosted payment gateway

This is the **single source of truth** for the wire format between the
Android app (`~/workspace/gateway-fixo-android/`) and the PHP server
(`~/workspace/gateway/`). If either side changes, update this file first.

## Endpoint

```
POST https://fi.xo.je/gateway/verify.php
```

* HTTPS only. The app refuses plain `http://` (and the manifest blocks
  cleartext traffic).
* The URL is configurable in the app's Settings screen; the value above
  is only the default.

## Request

### Headers

| Header | Value |
|---|---|
| `Content-Type` | `application/json` |
| `X-FIXO-Timestamp` | Unix time in seconds, e.g. `1794920776` |
| `X-FIXO-Signature` | Hex HMAC-SHA256 (see below) |

### Signature

```
signature = HMAC-SHA256(secret, timestamp + "." + rawBody)
```

* `secret` — the shared secret, entered once in the app and stored in
  `data/uddoktapay-config.php`-style server config (server side) /
  EncryptedSharedPreferences (app side). It is **never** in the source
  code on either side.
* `timestamp` — the exact string sent in `X-FIXO-Timestamp`.
* `rawBody` — the exact JSON bytes sent in the request body.
* The server must reject requests whose timestamp is more than **5
  minutes** old (replay protection) and must compare signatures in
  constant time (`hash_equals` in PHP).

### Body — payment

```json
{
  "provider": "bkash",
  "sender": "01712345678",
  "amount": "1000.00",
  "currency": "BDT",
  "trxid": "9HX7K2LMNP",
  "received_at": "2026-11-17T13:30:00Z",
  "device_id": "7f3a2c1e-…",
  "sms_hash": "a3f9…64 hex chars…"
}
```

| Field | Type | Notes |
|---|---|---|
| `provider` | string | `bkash` \| `nagad` \| `rocket` \| `upay` |
| `sender` | string | Customer mobile, `01XXXXXXXXX` (11 digits) |
| `amount` | string | Decimal with exactly 2 places, e.g. `"1000.00"`. Never a float. |
| `currency` | string | Always `"BDT"` |
| `trxid` | string | MFS transaction id as printed in the SMS (uppercase) |
| `received_at` | string | ISO-8601 UTC when the SMS arrived on the phone |
| `device_id` | string | Stable UUID of the phone, generated once in the app |
| `sms_hash` | string | SHA-256 hex of the raw SMS body — **idempotency key** |

### Body — test (connectivity check from the app's "Send test" button)

```json
{
  "test": true,
  "device_id": "7f3a2c1e-…",
  "sent_at": "2026-11-17T13:30:00Z"
}
```

Signed exactly like a payment. The server must answer **200** and
ignore it (no order, no delivery, no logging as a payment).

## Response

* **2xx** — accepted. The app treats it as delivered and removes the
  payment from its retry queue. The body is ignored (any JSON is fine,
  e.g. `{"ok": true}`).
* **Anything else (4xx/5xx/timeout/no network)** — NOT accepted. The app
  keeps the payment and retries with backoff (1, 2, 5, 15, 30, 60, 120,
  360, 720, 1440 minutes, then gives up after 24 h).

## Server responsibilities (PHP side)

1. Verify the HMAC and the timestamp window; reject bad signatures
   with **401** (no order changes).
2. **Deduplicate on `sms_hash`** — if a payment with this hash was
   already recorded, answer 2xx but do nothing (the app may retry a
   post whose first response was lost).
3. Match the payment to a pending order by **sender number + amount**
   (exact amount match; TrxID stored for the record). The UddoktaPay
   flow today does the same match from the Paymently app — keep the
   same rule so behaviour does not change for customers.
4. On a match: mark the order paid, deliver access (same as the
   UddoktaPay webhook does today), and record `provider`, `trxid`,
   `received_at`, `device_id` on the order.
5. On no match: log the payment for manual review and answer **200**
   (so the app stops retrying) — or answer **404** if you want the app
   to keep retrying for 24 h. Recommended: **200 + logged**, because a
   payment with no matching order is a human problem (wrong amount,
   wrong number), not a network problem.
6. Never trust `sender`/`amount`/`trxid` without the HMAC check.

## What the app guarantees

* It only ever POSTs payments parsed from SMS sent by the four known
  MFS sender IDs (bKash 16247, Nagad 16167, Rocket 16216, Upay 16268).
* It only POSTs money-IN messages where sender + amount + TrxID were
  all found. Unparseable messages are logged on the phone for review
  and are never posted.
* It never sends money, never reads non-MFS SMS, and never sends the
  raw SMS body to the server (only the parsed fields + its SHA-256).
