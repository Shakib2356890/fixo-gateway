# proguard rules — Fixo Gateway
# No minification is enabled (isMinifyEnabled = false), so this file is
# a placeholder for future release hardening.
-keep class com.fixo.gateway.** { *; }
