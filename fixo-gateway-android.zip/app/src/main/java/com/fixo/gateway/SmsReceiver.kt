package com.fixo.gateway

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Telephony
import android.telephony.SmsMessage

/**
 * Catches incoming SMS (manifest-registered, so it fires even when the app
 * is closed) and hands parsed payments to the poster.
 *
 * Flow: parse -> if parsed, enqueue + try an immediate POST on a worker
 * thread (goAsync keeps the receiver alive while the network call runs).
 * If the POST fails, the payment stays in the retry queue and the
 * foreground service picks it up. Unparseable MFS messages are logged
 * for human review; every other SMS is ignored completely.
 *
 * The receiver NEVER starts the foreground service itself — Android 12+
 * restricts that. The service is started by the app and at boot.
 */
class SmsReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        val pending = goAsync()
        Thread {
            try {
                handle(context, intent)
            } catch (e: Exception) {
                // Never crash the receiver — a missed SMS is worse than a logged error.
                try {
                    StatusStore(context.applicationContext)
                        .onPostFailed("receiver error: ${e.message}")
                } catch (ignored: Exception) { }
            } finally {
                pending.finish()
            }
        }.start()
    }

    private fun handle(context: Context, intent: Intent) {
        val appContext = context.applicationContext
        val settings = SettingsManager(appContext)
        val status = StatusStore(appContext)
        val queue = RetryQueue(appContext)

        val bundle = intent.extras ?: return
        val pdus = bundle.get("pdus") as? Array<*> ?: return
        val format = bundle.getString("format")
        val messages = pdus.mapNotNull { pdu ->
            try {
                val bytes = pdu as ByteArray
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    SmsMessage.createFromPdu(bytes, format)
                } else {
                    @Suppress("DEPRECATION")
                    SmsMessage.createFromPdu(bytes)
                }
            } catch (e: Exception) {
                null
            }
        }
        if (messages.isEmpty()) return

        // Group by sender (multipart SMS arrives as several parts of one message).
        val bySender = messages.groupBy { it.originatingAddress ?: "" }
        for ((sender, parts) in bySender) {
            val body = parts.joinToString("") { it.messageBody ?: "" }
            if (body.isBlank()) continue
            when (val r = SmsParser.parse(sender, body, settings.deviceId, settings.shopNumber)) {
                is SmsParser.Result.Ignored -> {
                    // Not an MFS payment SMS — ignore silently.
                }
                is SmsParser.Result.Unparseable -> {
                    status.logUnparseable(r.provider, r.reason, r.body)
                }
                is SmsParser.Result.Parsed -> {
                    val payment = r.payment
                    status.onSmsReceived("${payment.provider} ${payment.amount} from ${payment.sender}")
                    queue.enqueue(payment)
                    if (!settings.hasSecret) {
                        status.onPostFailed("no HMAC secret set — open the app and enter it")
                        continue
                    }
                    when (val post = PaymentPoster.postPayment(settings.serverUrl, settings.hmacSecret, payment)) {
                        is PaymentPoster.PostResult.Success -> {
                            queue.remove(payment.smsHash)
                            status.onPosted(payment.trxId)
                            GatewayService.kick(appContext) // refresh the notification counters
                        }
                        is PaymentPoster.PostResult.Failure -> {
                            status.onPostFailed(post.message)
                            queue.markFailed(payment.smsHash)
                        }
                    }
                }
            }
        }
    }
}
