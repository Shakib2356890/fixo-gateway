package com.fixo.gateway

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Payment history for the Payments tab (Paymently-style list).
 * One row per received payment: method, sender, amount, TrxID, time,
 * status (Pending / Posted / Failed). Stored as a JSON file in internal
 * storage — read-only list, no server calls, no new permissions.
 *
 * Writes happen only from RetryQueue, the single funnel every payment
 * passes through: enqueue() -> Pending, remove() -> Posted (remove is
 * only ever called after a successful POST), markFailed() dropping an
 * entry after 24 h -> Failed. History starts empty on upgrade to
 * v1.2.0 — payments received by older versions were never recorded.
 */
class PaymentHistory(context: Context) {

    companion object {
        const val STATUS_PENDING = "pending"
        const val STATUS_POSTED = "posted"
        const val STATUS_FAILED = "failed"
        private const val MAX_ENTRIES = 50
    }

    private val file = File(context.filesDir, "history.json")

    data class Entry(
        val smsHash: String,
        val provider: String,
        val sender: String,
        val amount: String,
        val trxId: String,
        val receivedAt: String,
        val status: String
    )

    @Synchronized
    fun record(payment: Payment, status: String) {
        val list = readAll().toMutableList()
        val idx = list.indexOfFirst { it.smsHash == payment.smsHash }
        val entry = Entry(
            payment.smsHash, payment.provider, payment.sender,
            payment.amount, payment.trxId, payment.receivedAt, status
        )
        if (idx >= 0) list[idx] = entry else list.add(0, entry)
        writeAll(list.take(MAX_ENTRIES))
    }

    @Synchronized
    fun recent(limit: Int = MAX_ENTRIES): List<Entry> = readAll().take(limit)

    private fun readAll(): List<Entry> {
        if (!file.exists()) return emptyList()
        return try {
            val arr = JSONArray(file.readText())
            val out = mutableListOf<Entry>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out += Entry(
                    o.optString("sms_hash"), o.optString("provider"),
                    o.optString("sender"), o.optString("amount"),
                    o.optString("trxid"), o.optString("received_at"),
                    o.optString("status", STATUS_PENDING)
                )
            }
            out
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun writeAll(list: List<Entry>) {
        try {
            val arr = JSONArray()
            for (e in list) {
                arr.put(JSONObject().apply {
                    put("sms_hash", e.smsHash)
                    put("provider", e.provider)
                    put("sender", e.sender)
                    put("amount", e.amount)
                    put("trxid", e.trxId)
                    put("received_at", e.receivedAt)
                    put("status", e.status)
                })
            }
            file.writeText(arr.toString())
        } catch (e: Exception) {
            // Storage failure: history is display-only; the payment itself
            // is safe in the retry queue, so nothing is lost.
        }
    }
}
