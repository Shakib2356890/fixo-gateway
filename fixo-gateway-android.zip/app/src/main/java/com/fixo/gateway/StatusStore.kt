package com.fixo.gateway

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * What the status screen shows: last SMS, last successful post, last error,
 * today's counts, and the log of unparseable MFS messages (for human review).
 * Stored in private SharedPreferences — no SMS body ever leaves the phone
 * except inside a signed payment POST to the shop server.
 */
class StatusStore(context: Context) {

    companion object {
        private const val PREFS = "gateway_status"
        private const val KEY_DATE = "date"
        private const val KEY_RECEIVED = "count_received"
        private const val KEY_POSTED = "count_posted"
        private const val KEY_FAILED = "count_failed"
        private const val KEY_LAST_SMS = "last_sms"
        private const val KEY_LAST_POST = "last_post"
        private const val KEY_LAST_ERROR = "last_error"
        private const val KEY_UNPARSEABLE = "unparseable_log"
        private const val MAX_UNPARSEABLE = 20
    }

    private val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun today(): String =
        SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    /** Zero the daily counters when the day rolls over. */
    private fun rolloverIfNeeded() {
        if (prefs.getString(KEY_DATE, "") != today()) {
            prefs.edit()
                .putString(KEY_DATE, today())
                .putInt(KEY_RECEIVED, 0)
                .putInt(KEY_POSTED, 0)
                .putInt(KEY_FAILED, 0)
                .apply()
        }
    }

    private fun stamp(): String =
        SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())

    fun countReceived(): Int { rolloverIfNeeded(); return prefs.getInt(KEY_RECEIVED, 0) }
    fun countPosted(): Int { rolloverIfNeeded(); return prefs.getInt(KEY_POSTED, 0) }
    fun countFailed(): Int { rolloverIfNeeded(); return prefs.getInt(KEY_FAILED, 0) }

    fun lastSms(): String = prefs.getString(KEY_LAST_SMS, "—") ?: "—"
    fun lastPost(): String = prefs.getString(KEY_LAST_POST, "—") ?: "—"
    fun lastError(): String = prefs.getString(KEY_LAST_ERROR, "—") ?: "—"

    fun onSmsReceived(summary: String) {
        rolloverIfNeeded()
        prefs.edit()
            .putInt(KEY_RECEIVED, prefs.getInt(KEY_RECEIVED, 0) + 1)
            .putString(KEY_LAST_SMS, "${stamp()}  $summary")
            .apply()
    }

    fun onPosted(trxId: String) {
        rolloverIfNeeded()
        prefs.edit()
            .putInt(KEY_POSTED, prefs.getInt(KEY_POSTED, 0) + 1)
            .putString(KEY_LAST_POST, "${stamp()}  $trxId")
            .apply()
    }

    fun onPostFailed(message: String) {
        rolloverIfNeeded()
        prefs.edit()
            .putInt(KEY_FAILED, prefs.getInt(KEY_FAILED, 0) + 1)
            .putString(KEY_LAST_ERROR, "${stamp()}  $message")
            .apply()
    }

    /** One unparseable MFS message, kept for review. Body is stored on-device only. */
    data class UnparseableEntry(val time: String, val provider: String, val reason: String, val body: String)

    fun logUnparseable(provider: String, reason: String, body: String) {
        val list = unparseableLog().toMutableList()
        list.add(0, UnparseableEntry(stamp(), provider, reason, body))
        val trimmed = list.take(MAX_UNPARSEABLE)
        val arr = JSONArray()
        for (e in trimmed) {
            arr.put(JSONObject().apply {
                put("time", e.time); put("provider", e.provider)
                put("reason", e.reason); put("body", e.body)
            })
        }
        prefs.edit().putString(KEY_UNPARSEABLE, arr.toString()).apply()
    }

    fun unparseableLog(): List<UnparseableEntry> {
        val raw = prefs.getString(KEY_UNPARSEABLE, "[]") ?: "[]"
        val out = mutableListOf<UnparseableEntry>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out += UnparseableEntry(
                    o.optString("time"), o.optString("provider"),
                    o.optString("reason"), o.optString("body")
                )
            }
        } catch (e: Exception) {
            // Corrupt log — drop it rather than crash.
        }
        return out
    }

    fun clearUnparseableLog() {
        prefs.edit().remove(KEY_UNPARSEABLE).apply()
    }
}
