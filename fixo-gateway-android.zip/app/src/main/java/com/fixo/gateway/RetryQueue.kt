package com.fixo.gateway

import android.content.Context
import org.json.JSONArray
import java.io.File

/**
 * Durable queue of payments that have not yet been accepted by the server.
 * Stored as a JSON file in internal storage (survives app kill and reboot).
 *
 * Backoff (minutes) after each failed attempt: 1, 2, 5, 15, 30, 60, 120,
 * 360, 720, then every 24 h. Entries older than 24 h are dropped to the
 * failed list — they stay visible on the status screen as "last error"
 * and can be re-queued manually from the app (the SMS itself is still on
 * the phone, so nothing is lost).
 */
class RetryQueue(context: Context) {

    companion object {
        private val BACKOFF_MINUTES = longArrayOf(1, 2, 5, 15, 30, 60, 120, 360, 720, 1440)
        private const val MAX_AGE_MILLIS = 24L * 60 * 60 * 1000
    }

    private val file = File(context.filesDir, "pending.json")

    // Payment history (v1.2.0): every state change flows through this
    // queue, so the history writes live here and nowhere else.
    private val history = PaymentHistory(context)

    @Synchronized
    fun all(): List<PendingPayment> {
        if (!file.exists()) return emptyList()
        return try {
            val arr = JSONArray(file.readText())
            val out = mutableListOf<PendingPayment>()
            for (i in 0 until arr.length()) {
                PendingPayment.fromJson(arr.getJSONObject(i))?.let { out += it }
            }
            out
        } catch (e: Exception) {
            emptyList()
        }
    }

    @Synchronized
    fun save(list: List<PendingPayment>) {
        try {
            val arr = JSONArray()
            for (p in list) arr.put(p.toJson())
            file.writeText(arr.toString())
        } catch (e: Exception) {
            // Storage failure: keep the in-memory state; the service will retry.
        }
    }

    @Synchronized
    fun enqueue(payment: Payment) {
        val list = all().toMutableList()
        // Dedupe on the SMS hash — a re-delivered SMS must not double-post.
        if (list.any { it.payment.smsHash == payment.smsHash }) return
        val now = System.currentTimeMillis()
        list += PendingPayment(payment, attempts = 0, nextRetryAtMillis = now, firstSeenAtMillis = now)
        save(list)
        history.record(payment, PaymentHistory.STATUS_PENDING)
    }

    @Synchronized
    fun remove(smsHash: String) {
        val found = all().find { it.payment.smsHash == smsHash }
        save(all().filter { it.payment.smsHash != smsHash })
        // remove() is only ever called after a successful POST.
        if (found != null) history.record(found.payment, PaymentHistory.STATUS_POSTED)
    }

    /** Mark a failed attempt and schedule the next retry (or drop if too old). */
    @Synchronized
    fun markFailed(smsHash: String): Boolean {
        val now = System.currentTimeMillis()
        val kept = mutableListOf<PendingPayment>()
        var dropped = false
        for (p in all()) {
            if (p.payment.smsHash != smsHash) {
                kept += p
                continue
            }
            val attempts = p.attempts + 1
            val expired = now - p.firstSeenAtMillis > MAX_AGE_MILLIS
            if (expired) {
                dropped = true
                history.record(p.payment, PaymentHistory.STATUS_FAILED)
                continue
            }
            val backoff = BACKOFF_MINUTES[minOf(attempts - 1, BACKOFF_MINUTES.size - 1)]
            kept += p.copy(attempts = attempts, nextRetryAtMillis = now + backoff * 60 * 1000)
        }
        save(kept)
        return dropped
    }

    @Synchronized
    fun dueNow(): List<PendingPayment> {
        val now = System.currentTimeMillis()
        return all().filter { it.nextRetryAtMillis <= now }
    }

    @Synchronized
    fun count(): Int = all().size
}
