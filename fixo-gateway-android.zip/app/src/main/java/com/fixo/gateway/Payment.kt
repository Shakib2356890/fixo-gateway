package com.fixo.gateway

import org.json.JSONObject
import java.math.BigDecimal
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/** One parsed incoming payment. Amount is a decimal string ("1000.00") — never a float. */
data class Payment(
    val provider: String,      // "bkash" | "nagad" | "rocket" | "upay"
    val sender: String,        // customer mobile, e.g. "01712345678"
    val amount: String,        // e.g. "1000.00"
    val trxId: String,         // e.g. "9HX7K2LMNP"
    val receivedAt: String,    // ISO-8601 UTC, e.g. "2026-11-17T13:30:00Z"
    val deviceId: String,
    val smsHash: String        // SHA-256 of the raw SMS body — server idempotency key
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("provider", provider)
        put("sender", sender)
        put("amount", amount)
        put("currency", "BDT")
        put("trxid", trxId)
        put("received_at", receivedAt)
        put("device_id", deviceId)
        put("sms_hash", smsHash)
    }

    companion object {
        fun isoNow(): String {
            val f = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US)
            f.timeZone = TimeZone.getTimeZone("UTC")
            return f.format(Date())
        }

        fun sha256Hex(text: String): String {
            val d = MessageDigest.getInstance("SHA-256").digest(text.toByteArray(Charsets.UTF_8))
            return d.joinToString("") { "%02x".format(it) }
        }

        /** Normalise an amount string ("1,000.00") to exactly two decimals. */
        fun normaliseAmount(raw: String): String? = try {
            val bd = BigDecimal(raw.replace(",", "").trim())
            if (bd <= BigDecimal.ZERO) null
            else bd.setScale(2, java.math.RoundingMode.HALF_UP).toPlainString()
        } catch (e: Exception) {
            null
        }
    }
}

/** A payment waiting for a successful POST, with retry bookkeeping. */
data class PendingPayment(
    val payment: Payment,
    val attempts: Int,
    val nextRetryAtMillis: Long,
    val firstSeenAtMillis: Long
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("payment", payment.toJson())
        put("attempts", attempts)
        put("next_retry_at", nextRetryAtMillis)
        put("first_seen_at", firstSeenAtMillis)
    }

    companion object {
        fun fromJson(o: JSONObject): PendingPayment? = try {
            val p = o.getJSONObject("payment")
            PendingPayment(
                payment = Payment(
                    provider = p.getString("provider"),
                    sender = p.getString("sender"),
                    amount = p.getString("amount"),
                    trxId = p.getString("trxid"),
                    receivedAt = p.getString("received_at"),
                    deviceId = p.getString("device_id"),
                    smsHash = p.getString("sms_hash")
                ),
                attempts = o.getInt("attempts"),
                nextRetryAtMillis = o.getLong("next_retry_at"),
                firstSeenAtMillis = o.getLong("first_seen_at")
            )
        } catch (e: Exception) {
            null
        }
    }
}
