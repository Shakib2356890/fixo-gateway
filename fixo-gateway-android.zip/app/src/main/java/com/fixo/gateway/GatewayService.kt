package com.fixo.gateway

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat

/**
 * Foreground service: shows the persistent status notification and runs
 * the retry loop (every 60 s) for payments the immediate POST could not
 * deliver. Started from the app and at boot; START_STICKY restarts it
 * if the system kills it.
 */
class GatewayService : Service() {

    companion object {
        private const val NOTIFICATION_ID = 1
        private const val CHANNEL_ID = "fixo_gateway"
        private const val RETRY_INTERVAL_MS = 60_000L

        fun start(context: Context) {
            val intent = Intent(context, GatewayService::class.java)
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(intent)
                } else {
                    context.startService(intent)
                }
            } catch (e: Exception) {
                // Foreground-service start blocked (e.g. background restrictions) —
                // the user can start it from the app; the SMS receiver still works.
            }
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, GatewayService::class.java))
        }

        /** Nudge the service to refresh its notification (after a new SMS). */
        fun kick(context: Context) {
            val intent = Intent(context, GatewayService::class.java)
                .setAction("com.fixo.gateway.REFRESH")
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(intent)
                } else {
                    context.startService(intent)
                }
            } catch (ignored: Exception) { }
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private var running = false

    private val retryRunnable = object : Runnable {
        override fun run() {
            if (!running) return
            processRetries()
            handler.postDelayed(this, RETRY_INTERVAL_MS)
        }
    }

    override fun onCreate() {
        super.onCreate()
        createChannel()
        running = true
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIFICATION_ID, buildNotification())
        handler.removeCallbacks(retryRunnable)
        handler.post(retryRunnable)
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        handler.removeCallbacks(retryRunnable)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Fixo Gateway",
                NotificationManager.IMPORTANCE_LOW
            ).apply { description = "Payment SMS relay status" }
            getSystemService(NotificationManager::class.java)?.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val status = StatusStore(this)
        val queue = RetryQueue(this)
        val text = "Today: ${status.countReceived()} received · " +
            "${status.countPosted()} posted · ${queue.count()} pending"
        val openApp = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Fixo Gateway — listening for payment SMS")
            .setContentText(text)
            .setContentIntent(openApp)
            .setOngoing(true)
            .build()
    }

    private fun processRetries() {
        Thread {
            try {
                val settings = SettingsManager(applicationContext)
                val status = StatusStore(applicationContext)
                val queue = RetryQueue(applicationContext)
                if (!settings.hasSecret) return@Thread
                for (pending in queue.dueNow()) {
                    val payment = pending.payment
                    when (val post = PaymentPoster.postPayment(settings.serverUrl, settings.hmacSecret, payment)) {
                        is PaymentPoster.PostResult.Success -> {
                            queue.remove(payment.smsHash)
                            status.onPosted(payment.trxId)
                        }
                        is PaymentPoster.PostResult.Failure -> {
                            status.onPostFailed(post.message)
                            queue.markFailed(payment.smsHash)
                        }
                    }
                }
            } catch (ignored: Exception) {
                // Retry next round; nothing is lost — the queue is durable.
            }
            // Notification updates must run on the main thread.
            handler.post { startForeground(NOTIFICATION_ID, buildNotification()) }
        }.start()
    }
}
