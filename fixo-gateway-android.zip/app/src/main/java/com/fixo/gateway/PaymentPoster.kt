package com.fixo.gateway

import org.json.JSONObject
import java.io.OutputStreamWriter
import java.net.URL
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec
import javax.net.ssl.HttpsURLConnection

/**
 * POSTs a payment to the shop server, signed with HMAC-SHA256.
 *
 * Contract (see CONTRACT.md — the server must implement exactly this):
 *   POST {serverUrl}  (default https://fi.xo.je/gateway/verify.php)
 *   Content-Type: application/x-www-form-urlencoded
 *   X-FIXO-Timestamp: <unix seconds>
 *   X-FIXO-Signature: <hex HMAC-SHA256(secret, timestamp + "." + formBody)>
 *   Body: form field "data" holding the payment JSON (see Payment.toJson),
 *   URL-encoded. InfinityFree's host layer 400s raw JSON POSTs from the
 *   app (v1.2.0 got "server answered HTTP 400" on Send test); a
 *   browser-style form POST is what browsers send natively.
 *
 * Any 2xx response = accepted. Anything else (non-2xx, timeout, no
 * network) = failure — the payment stays in the retry queue.
 * HTTPS only; cleartext is blocked by the manifest (usesCleartextTraffic=false).
 */
object PaymentPoster {

    private const val CONNECT_TIMEOUT_MS = 15_000
    private const val READ_TIMEOUT_MS = 20_000

    // Chrome on Android — InfinityFree's free hosting 403-blocks API-style
    // requests from non-browser clients (v1.1.0 got "server answered
    // HTTP 403" on Send test). Browser-like headers so the POST is
    // treated as a normal browser request.
    private const val BROWSER_USER_AGENT =
        "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36"

    sealed class PostResult {
        object Success : PostResult()
        data class Failure(val message: String) : PostResult()
    }

    /** HMAC-SHA256, hex lowercase. */
    fun hmacSha256Hex(secret: String, message: String): String {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(secret.toByteArray(StandardCharsets.UTF_8), "HmacSHA256"))
        val bytes = mac.doFinal(message.toByteArray(StandardCharsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }

    fun postPayment(serverUrl: String, secret: String, payment: Payment): PostResult {
        return postForm(serverUrl, secret, payment.toJson())
    }

    /** Connectivity test — the server must answer 200 and ignore test payloads. */
    fun postTest(serverUrl: String, secret: String, deviceId: String): PostResult {
        val body = JSONObject().apply {
            put("test", true)
            put("device_id", deviceId)
            put("sent_at", Payment.isoNow())
        }
        return postForm(serverUrl, secret, body)
    }

    private fun postForm(serverUrl: String, secret: String, body: JSONObject): PostResult {
        // The JSON rides as a form field, exactly like a browser form
        // submit; the HMAC signs the exact form string sent, so the
        // server (which verifies over php://input) sees the same bytes.
        val formBody = "data=" + URLEncoder.encode(body.toString(), "UTF-8")
        val timestamp = (System.currentTimeMillis() / 1000).toString()
        val signature = try {
            hmacSha256Hex(secret, "$timestamp.$formBody")
        } catch (e: Exception) {
            return PostResult.Failure("signing failed: ${e.message}")
        }
        return try {
            val url = URL(serverUrl)
            require(url.protocol == "https") { "server URL must be https" }
            val conn = url.openConnection() as HttpsURLConnection
            conn.requestMethod = "POST"
            conn.connectTimeout = CONNECT_TIMEOUT_MS
            conn.readTimeout = READ_TIMEOUT_MS
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
            conn.setRequestProperty("User-Agent", BROWSER_USER_AGENT)
            conn.setRequestProperty("Accept", "application/json")
            conn.setRequestProperty("Accept-Language", "en-US,en;q=0.9")
            conn.setRequestProperty("X-FIXO-Timestamp", timestamp)
            conn.setRequestProperty("X-FIXO-Signature", signature)
            OutputStreamWriter(conn.outputStream, StandardCharsets.UTF_8).use { it.write(formBody) }
            val code = conn.responseCode
            // Read the response body: a 2xx from the host's bot-check page
            // is HTML, not our JSON — only {"status":"ok"} counts as
            // accepted, otherwise the payment must stay in the retry queue.
            val bodyText = try {
                (if (code in 200..299) conn.inputStream else conn.errorStream)
                    ?.bufferedReader()?.use { it.readText() } ?: ""
            } catch (ignored: Exception) { "" }
            conn.disconnect()
            if (code !in 200..299) return PostResult.Failure("server answered HTTP $code")
            val ok = try {
                JSONObject(bodyText).optString("status") == "ok"
            } catch (ignored: Exception) { false }
            if (ok) PostResult.Success
            else PostResult.Failure("unexpected response (HTTP $code)")
        } catch (e: Exception) {
            PostResult.Failure(e.message ?: e.javaClass.simpleName)
        }
    }
}
