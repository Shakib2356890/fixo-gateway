package com.fixo.gateway

import org.json.JSONObject
import java.io.OutputStreamWriter
import java.net.URL
import java.nio.charset.StandardCharsets
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec
import javax.net.ssl.HttpsURLConnection

/**
 * POSTs a payment to the shop server, signed with HMAC-SHA256.
 *
 * Contract (see CONTRACT.md — the server must implement exactly this):
 *   POST {serverUrl}  (default https://fi.xo.je/gateway/verify.php)
 *   Content-Type: application/json
 *   X-FIXO-Timestamp: <unix seconds>
 *   X-FIXO-Signature: <hex HMAC-SHA256(secret, timestamp + "." + rawBody)>
 *   Body: the payment JSON (see Payment.toJson).
 *
 * Any 2xx response = accepted. Anything else (non-2xx, timeout, no
 * network) = failure — the payment stays in the retry queue.
 * HTTPS only; cleartext is blocked by the manifest (usesCleartextTraffic=false).
 */
object PaymentPoster {

    private const val CONNECT_TIMEOUT_MS = 15_000
    private const val READ_TIMEOUT_MS = 20_000

    sealed class PostResult {
        object Success : PostResult()
        data class Failure(val message: String) : PostResult()
    }

    /** HMAC-SHA256, hex lowercase. */
    fun hmacSha256Hex(secret: String, message: String): String {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(secret.toByteArray(StandardCharsets.UTF_8), "HmacSHA256"))
        val bytes = mac.doFinal(message.toByteArray(StandardCharsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }

    fun postPayment(serverUrl: String, secret: String, payment: Payment): PostResult {
        return postJson(serverUrl, secret, payment.toJson())
    }

    /** Connectivity test — the server must answer 200 and ignore test payloads. */
    fun postTest(serverUrl: String, secret: String, deviceId: String): PostResult {
        val body = JSONObject().apply {
            put("test", true)
            put("device_id", deviceId)
            put("sent_at", Payment.isoNow())
        }
        return postJson(serverUrl, secret, body)
    }

    private fun postJson(serverUrl: String, secret: String, body: JSONObject): PostResult {
        val rawBody = body.toString()
        val timestamp = (System.currentTimeMillis() / 1000).toString()
        val signature = try {
            hmacSha256Hex(secret, "$timestamp.$rawBody")
        } catch (e: Exception) {
            return PostResult.Failure("signing failed: ${e.message}")
        }
        return try {
            val url = URL(serverUrl)
            require(url.protocol == "https") { "server URL must be https" }
            val conn = url.openConnection() as HttpsURLConnection
            conn.requestMethod = "POST"
            conn.connectTimeout = CONNECT_TIMEOUT_MS
            conn.readTimeout = READ_TIMEOUT_MS
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("X-FIXO-Timestamp", timestamp)
            conn.setRequestProperty("X-FIXO-Signature", signature)
            OutputStreamWriter(conn.outputStream, StandardCharsets.UTF_8).use { it.write(rawBody) }
            val code = conn.responseCode
            // Read (and discard) the response body so the connection can be reused.
            try { conn.inputStream?.bufferedReader()?.use { it.readText() } } catch (ignored: Exception) { }
            conn.disconnect()
            if (code in 200..299) PostResult.Success
            else PostResult.Failure("server answered HTTP $code")
        } catch (e: Exception) {
            PostResult.Failure(e.message ?: e.javaClass.simpleName)
        }
    }
}
