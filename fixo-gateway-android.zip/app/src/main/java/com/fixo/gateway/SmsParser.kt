package com.fixo.gateway

/**
 * Parses incoming MFS payment SMS (bKash / Nagad / Rocket / Upay).
 *
 * Rules:
 *  - Only SMS from the four known MFS sender IDs are ever considered.
 *    Anything else is ignored completely (not even logged).
 *  - Only money-IN messages count ("received" / "credited" / "added").
 *    Money-OUT messages (cash-out, send-money confirmations) are ignored.
 *  - A message is only a payment when sender number + amount + TrxID
 *    are ALL found. Anything less is returned as Unparseable with the
 *    missing fields named — the app NEVER guesses a value.
 *  - Amounts are parsed defensively: first "Tk/BDT" amount in the body
 *    (the received amount comes before the balance in every known format).
 */
object SmsParser {

    /** sender address (lowercase) -> provider. Numeric short codes included. */
    private val PROVIDERS = listOf(
        "bkash" to "bkash", "16247" to "bkash",
        "nagad" to "nagad", "16167" to "nagad",
        "rocket" to "rocket", "16216" to "rocket",
        "upay" to "upay", "16268" to "upay"
    )

    /** The shop's own MFS number — an SMS "from" this number is money OUT, never a payment. */
    const val SHOP_NUMBER = "01328257898"

    private val MONEY_IN_WORDS = listOf("receiv", "credit", "added", "deposit")
    private val MONEY_OUT_WORDS = listOf("cash out", "cashout", "send money", "sent tk", "payment successful")

    private val AMOUNT_RE = Regex("""(?:Tk\.?|BDT|Taka)\s*([0-9][0-9,]*\.?[0-9]{0,2})""", RegexOption.IGNORE_CASE)
    private val SENDER_AFTER_FROM_RE = Regex("""(?:from|frm)\s*:?\s*(?:\+?880|0)?(1[3-9]\d{8})""", RegexOption.IGNORE_CASE)
    private val ANY_BD_NUMBER_RE = Regex("""(?:\+?880|0)(1[3-9]\d{8})""")
    private val TRXID_RE = Regex("""(?:trx\s*id|transaction\s*id|txn\s*id|trxID)\s*:?\s*([A-Za-z0-9]{6,20})""", RegexOption.IGNORE_CASE)

    sealed class Result {
        data class Parsed(val payment: Payment) : Result()
        /** Known MFS sender, but not a usable payment SMS. Body kept for human review. */
        data class Unparseable(val provider: String, val reason: String, val body: String) : Result()
        /** Not an MFS payment SMS at all — ignore silently. */
        object Ignored : Result()
    }

    fun providerOf(senderAddress: String?): String? {
        if (senderAddress.isNullOrBlank()) return null
        val s = senderAddress.lowercase()
        for ((key, provider) in PROVIDERS) {
            if (s.contains(key)) return provider
        }
        return null
    }

    /**
     * @param senderAddress the SMS sender as delivered by the system (e.g. "bKash", "16247")
     * @param body the full SMS text
     * @param deviceId this phone's stable gateway device id
     * @param shopNumber the shop's own MFS number — SMS "from" this number is money OUT
     */
    fun parse(
        senderAddress: String?,
        body: String,
        deviceId: String,
        shopNumber: String = SHOP_NUMBER
    ): Result {
        val provider = providerOf(senderAddress) ?: return Result.Ignored
        val lower = body.lowercase()

        val looksMoneyIn = MONEY_IN_WORDS.any { lower.contains(it) }
        val looksMoneyOut = MONEY_OUT_WORDS.any { lower.contains(it) }
        if (!looksMoneyIn || looksMoneyOut) return Result.Ignored

        val missing = mutableListOf<String>()

        // Amount — first Tk/BDT figure in the body.
        val amountRaw = AMOUNT_RE.find(body)?.groupValues?.getOrNull(1)
        val amount = amountRaw?.let { Payment.normaliseAmount(it) }
        if (amount == null) {
            missing += "amount"
        } else {
            // Sanity: a single payment over ৳10,00,000 is not a real shop payment.
            val v = amount.toBigDecimalOrNull()
            if (v == null || v > java.math.BigDecimal("1000000")) missing += "amount(unrealistic)"
        }

        // Sender — the mobile number after "from"; fallback: any BD number in the body.
        val senderMatch = SENDER_AFTER_FROM_RE.find(body)?.groupValues?.getOrNull(1)
            ?: ANY_BD_NUMBER_RE.find(body)?.groupValues?.getOrNull(1)
        val sender = senderMatch?.let { "0$it" }
        if (sender == null) {
            missing += "sender"
        } else if (sender == shopNumber) {
            return Result.Ignored // our own number — money moving out, not a customer payment
        }

        // TrxID.
        val trxId = TRXID_RE.find(body)?.groupValues?.getOrNull(1)?.uppercase()
        if (trxId == null) missing += "trxid"

        if (missing.isNotEmpty()) {
            return Result.Unparseable(
                provider = provider,
                reason = "missing: " + missing.joinToString(", "),
                body = body
            )
        }

        return Result.Parsed(
            Payment(
                provider = provider,
                sender = sender!!,
                amount = amount!!,
                trxId = trxId!!,
                receivedAt = Payment.isoNow(),
                deviceId = deviceId,
                smsHash = Payment.sha256Hex(body)
            )
        )
    }
}
