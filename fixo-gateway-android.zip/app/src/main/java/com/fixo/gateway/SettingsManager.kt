package com.fixo.gateway

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import java.util.UUID

/**
 * All app configuration.
 *
 * The HMAC secret lives ONLY in EncryptedSharedPreferences (hardware-backed
 * keystore where available). It is entered once on the settings screen and
 * is never hardcoded, never logged, and never leaves the phone except as
 * an HMAC signature. The server URL and shop number are public values
 * and are stored in plain preferences.
 */
class SettingsManager(context: Context) {

    companion object {
        const val DEFAULT_SERVER_URL = "https://fi.xo.je/gateway/verify.php"
        const val DEFAULT_SHOP_NUMBER = "01328257898"
        private const val PREFS_NAME = "gateway_settings"
        private const val KEY_SERVER_URL = "server_url"
        private const val KEY_DEVICE_ID = "device_id"
        private const val KEY_SHOP_NUMBER = "shop_number"
        private const val KEY_START_ON_BOOT = "start_on_boot"
        private const val KEY_HMAC_SECRET = "hmac_secret"
    }

    private val prefs: SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    /** Encrypted store — created lazily; falls back to plain prefs only if the keystore is broken. */
    private val encrypted: SharedPreferences by lazy {
        try {
            val masterKey = MasterKey.Builder(context)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()
            EncryptedSharedPreferences.create(
                context,
                "gateway_secrets",
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        } catch (e: Exception) {
            // Keystore unavailable (rare) — still never hardcode; store in private prefs.
            context.getSharedPreferences("gateway_secrets_fallback", Context.MODE_PRIVATE)
        }
    }

    var serverUrl: String
        get() = prefs.getString(KEY_SERVER_URL, DEFAULT_SERVER_URL) ?: DEFAULT_SERVER_URL
        set(v) = prefs.edit().putString(KEY_SERVER_URL, v.trim()).apply()

    var shopNumber: String
        get() = prefs.getString(KEY_SHOP_NUMBER, DEFAULT_SHOP_NUMBER) ?: DEFAULT_SHOP_NUMBER
        set(v) = prefs.edit().putString(KEY_SHOP_NUMBER, v.trim()).apply()

    var startOnBoot: Boolean
        get() = prefs.getBoolean(KEY_START_ON_BOOT, true)
        set(v) = prefs.edit().putBoolean(KEY_START_ON_BOOT, v).apply()

    /** Stable id for this phone, generated once. Shown on the status screen. */
    val deviceId: String
        get() {
            var id = prefs.getString(KEY_DEVICE_ID, null)
            if (id.isNullOrBlank()) {
                id = UUID.randomUUID().toString()
                prefs.edit().putString(KEY_DEVICE_ID, id).apply()
            }
            return id
        }

    /** The shared secret for HMAC signing. Empty until the owner enters it once. */
    var hmacSecret: String
        get() = encrypted.getString(KEY_HMAC_SECRET, "") ?: ""
        set(v) = encrypted.edit().putString(KEY_HMAC_SECRET, v).apply()

    val hasSecret: Boolean get() = hmacSecret.isNotEmpty()
}
