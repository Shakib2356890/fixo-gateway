package com.fixo.gateway

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import java.util.UUID

/**
 * All app configuration.
 *
 * v1.2.4: the InfinityFree anti-bot cookie is stored here (plain
 * prefs — it is a session cookie, not a secret). A hidden WebView
 * (BotCookieFetcher) obtains it once by loading the shop homepage
 * like a real browser; PaymentPoster sends it with every POST so
 * the host's JS challenge page stops intercepting our requests.
 *
 * v1.2.3: the HMAC secret is BAKED IN at build time via BuildConfig
 * (Gradle property fixoHmacSecret, passed from the GitHub Actions
 * secret FIXO_HMAC_SECRET) — it is never typed into the app, never
 * logged, and never leaves the phone except as an HMAC signature.
 * The Settings field for the secret is gone. A secret already stored
 * in EncryptedSharedPreferences is kept only as a fallback if the
 * baked-in value is empty (e.g. a local build without the property).
 *
 * v1.2.2: the server URL and the shop number are FIXED constants now —
 * they never change, so there is no field for them anywhere in the app.
 */
class SettingsManager(context: Context) {

    companion object {
        const val DEFAULT_SERVER_URL = "https://fi.xo.je/gateway/verify.php"
        const val DEFAULT_SHOP_NUMBER = "01328257898"
        private const val PREFS_NAME = "gateway_settings"
        private const val KEY_DEVICE_ID = "device_id"
        private const val KEY_START_ON_BOOT = "start_on_boot"
        private const val KEY_HMAC_SECRET = "hmac_secret"
        private const val KEY_BOT_COOKIE = "infinityfree_cookie"
    }

    private val prefs: SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    /** Encrypted store — created lazily; falls back to plain prefs only if the keystore is broken. */
    private val encrypted: SharedPreferences by lazy {
        try {
            val masterKey = MasterKey.Builder(context)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()
            EncryptedSharedPreferences.create(
                context,
                "gateway_secrets",
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        } catch (e: Exception) {
            // Keystore unavailable (rare) — still never hardcode; store in private prefs.
            context.getSharedPreferences("gateway_secrets_fallback", Context.MODE_PRIVATE)
        }
    }

    /** Fixed — the shop's gateway endpoint. Never changes, never edited. */
    val serverUrl: String get() = DEFAULT_SERVER_URL

    /** Fixed — the shop's MFS number (payments go TO this number). */
    val shopNumber: String get() = DEFAULT_SHOP_NUMBER

    var startOnBoot: Boolean
        get() = prefs.getBoolean(KEY_START_ON_BOOT, true)
        set(v) = prefs.edit().putBoolean(KEY_START_ON_BOOT, v).apply()

    /** Stable id for this phone, generated once. Shown on the status screen. */
    val deviceId: String
        get() {
            var id = prefs.getString(KEY_DEVICE_ID, null)
            if (id.isNullOrBlank()) {
                id = UUID.randomUUID().toString()
                prefs.edit().putString(KEY_DEVICE_ID, id).apply()
            }
            return id
        }

    /** The HMAC secret baked in at build time (BuildConfig). Empty on a local build without the Gradle property. */
    val bakedSecret: String get() = BuildConfig.HMAC_SECRET

    /** The shared secret for HMAC signing: the baked-in value first, the stored encrypted value as fallback. */
    var hmacSecret: String
        get() = bakedSecret.ifEmpty { encrypted.getString(KEY_HMAC_SECRET, "") ?: "" }
        set(v) = encrypted.edit().putString(KEY_HMAC_SECRET, v).apply()

    val hasSecret: Boolean
        get() = bakedSecret.isNotEmpty() ||
            (encrypted.getString(KEY_HMAC_SECRET, "") ?: "").isNotEmpty()

    /**
     * InfinityFree anti-bot session cookie (v1.2.4), stored in plain
     * prefs — it is a session cookie, not a secret. Obtained by the
     * hidden WebView (BotCookieFetcher) and sent with every POST so
     * the host's JS challenge page stops intercepting our requests.
     * Empty until the first fetch; a stale cookie just means the next
     * POST gets the challenge page again and the caller refreshes it.
     */
    var botCookie: String
        get() = prefs.getString(KEY_BOT_COOKIE, "") ?: ""
        set(v) = prefs.edit().putString(KEY_BOT_COOKIE, v).apply()

    val hasBotCookie: Boolean get() = botCookie.isNotEmpty()
}
