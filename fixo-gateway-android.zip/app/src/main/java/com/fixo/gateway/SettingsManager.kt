package com.fixo.gateway

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import java.util.UUID

/**
 * All app configuration.
 *
 * The HMAC secret lives ONLY in EncryptedSharedPreferences (hardware-backed
 * keystore where available). It is entered once on the settings screen and
 * is never hardcoded, never logged, and never leaves the phone except as
 * an HMAC signature.
 *
 * v1.2.2: the server URL and the shop number are FIXED constants now —
 * they never change, so there is no field for them anywhere in the app.
 * Upgrades keep the secret that is already stored encrypted on the
 * phone; a fresh install shows one secret field on Settings, once.
 */
class SettingsManager(context: Context) {

    companion object {
        const val DEFAULT_SERVER_URL = "https://fi.xo.je/gateway/verify.php"
        const val DEFAULT_SHOP_NUMBER = "01328257898"
        private const val PREFS_NAME = "gateway_settings"
        private const val KEY_DEVICE_ID = "device_id"
        private const val KEY_START_ON_BOOT = "start_on_boot"
        private const val KEY_HMAC_SECRET = "hmac_secret"
    }

    private val prefs: SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    /** Encrypted store — created lazily; falls back to plain prefs only if the keystore is broken. */
    private val encrypted: SharedPreferences by lazy {
        try {
            val masterKey = MasterKey.Builder(context)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()
            EncryptedSharedPreferences.create(
                context,
                "gateway_secrets",
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        } catch (e: Exception) {
            // Keystore unavailable (rare) — still never hardcode; store in private prefs.
            context.getSharedPreferences("gateway_secrets_fallback", Context.MODE_PRIVATE)
        }
    }

    /** Fixed — the shop's gateway endpoint. Never changes, never edited. */
    val serverUrl: String get() = DEFAULT_SERVER_URL

    /** Fixed — the shop's MFS number (payments go TO this number). */
    val shopNumber: String get() = DEFAULT_SHOP_NUMBER

    var startOnBoot: Boolean
        get() = prefs.getBoolean(KEY_START_ON_BOOT, true)
        set(v) = prefs.edit().putBoolean(KEY_START_ON_BOOT, v).apply()

    /** Stable id for this phone, generated once. Shown on the status screen. */
    val deviceId: String
        get() {
            var id = prefs.getString(KEY_DEVICE_ID, null)
            if (id.isNullOrBlank()) {
                id = UUID.randomUUID().toString()
                prefs.edit().putString(KEY_DEVICE_ID, id).apply()
            }
            return id
        }

    /** The shared secret for HMAC signing. Empty until the owner enters it once. */
    var hmacSecret: String
        get() = encrypted.getString(KEY_HMAC_SECRET, "") ?: ""
        set(v) = encrypted.edit().putString(KEY_HMAC_SECRET, v).apply()

    val hasSecret: Boolean get() = hmacSecret.isNotEmpty()
}
