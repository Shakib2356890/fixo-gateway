package com.fixo.gateway

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout

/**
 * Tab host: Dashboard (WebView of the shop admin) + Payments (SMS
 * status) + Settings.
 *
 * Everything the owner needs:
 *  - Dashboard: https://fi.xo.je/admin in a WebView — orders, sales and
 *    the gateway admin, in the shop's own design. Pull down to refresh.
 *    Google sign-in is blocked by Google inside any embedded WebView,
 *    so tapping "Continue with Google" shows an "Open in browser"
 *    button instead (no hack, no workaround). The email + password
 *    form on the sign-in page works inside the app.
 *  - Payments: is the service running, is SMS permission granted, is
 *    battery optimisation off, today's counts, last SMS, last
 *    successful post, last error, pending queue, test post, retry.
 *  - Settings: server URL + HMAC secret (entered once, stored
 *    encrypted), shop number, start on boot.
 *
 * The SMS relay itself (SmsReceiver / SmsParser / PaymentPoster /
 * RetryQueue / GatewayService) is untouched by the dashboard — it runs
 * in the background service whether or not this screen is open.
 */
class MainActivity : AppCompatActivity() {

    companion object {
        private const val PERMISSION_REQUEST_CODE = 100
        private const val ADMIN_URL = "https://fi.xo.je/admin"
        private const val TAB_DASHBOARD = 0
        private const val TAB_PAYMENTS = 1
        private const val TAB_SETTINGS = 2
    }

    private lateinit var settings: SettingsManager
    private lateinit var status: StatusStore
    private lateinit var queue: RetryQueue

    // Tabs
    private lateinit var tabDashboard: View
    private lateinit var tabPayments: View
    private lateinit var tabSettings: View
    private lateinit var btnTabDashboard: Button
    private lateinit var btnTabPayments: Button
    private lateinit var btnTabSettings: Button
    private var currentTab = TAB_DASHBOARD

    // Dashboard (WebView)
    private lateinit var webView: WebView
    private lateinit var swipeRefresh: SwipeRefreshLayout
    private lateinit var bannerSignin: LinearLayout
    private lateinit var tvBannerMessage: TextView
    private var webViewLoaded = false
    private var bannerIsError = false

    // Payments tab
    private lateinit var tvService: TextView
    private lateinit var tvPermission: TextView
    private lateinit var tvBattery: TextView
    private lateinit var tvCounts: TextView
    private lateinit var tvLastSms: TextView
    private lateinit var tvLastPost: TextView
    private lateinit var tvLastError: TextView
    private lateinit var tvPending: TextView
    private lateinit var tvDeviceId: TextView
    private lateinit var tvUnparseable: TextView

    // Settings tab
    private lateinit var etServerUrl: EditText
    private lateinit var etSecret: EditText
    private lateinit var etShopNumber: EditText
    private lateinit var cbStartOnBoot: CheckBox

    private val refreshHandler = Handler(Looper.getMainLooper())
    private val refreshRunnable = object : Runnable {
        override fun run() {
            refreshStatus()
            refreshHandler.postDelayed(this, 5_000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        settings = SettingsManager(this)
        status = StatusStore(this)
        queue = RetryQueue(this)

        // Tabs
        tabDashboard = findViewById(R.id.tab_dashboard)
        tabPayments = findViewById(R.id.tab_payments)
        tabSettings = findViewById(R.id.tab_settings)
        btnTabDashboard = findViewById(R.id.btn_tab_dashboard)
        btnTabPayments = findViewById(R.id.btn_tab_payments)
        btnTabSettings = findViewById(R.id.btn_tab_settings)
        btnTabDashboard.setOnClickListener { showTab(TAB_DASHBOARD) }
        btnTabPayments.setOnClickListener { showTab(TAB_PAYMENTS) }
        btnTabSettings.setOnClickListener { showTab(TAB_SETTINGS) }

        // Dashboard
        webView = findViewById(R.id.webview)
        swipeRefresh = findViewById(R.id.swipe_refresh)
        bannerSignin = findViewById(R.id.banner_signin)
        tvBannerMessage = findViewById(R.id.tv_banner_message)
        findViewById<Button>(R.id.btn_open_browser).setOnClickListener { openInBrowser() }
        findViewById<Button>(R.id.btn_banner_dismiss).setOnClickListener { hideBanner() }
        setupWebView()

        // Payments tab
        tvService = findViewById(R.id.tv_service)
        tvPermission = findViewById(R.id.tv_permission)
        tvBattery = findViewById(R.id.tv_battery)
        tvCounts = findViewById(R.id.tv_counts)
        tvLastSms = findViewById(R.id.tv_last_sms)
        tvLastPost = findViewById(R.id.tv_last_post)
        tvLastError = findViewById(R.id.tv_last_error)
        tvPending = findViewById(R.id.tv_pending)
        tvDeviceId = findViewById(R.id.tv_device_id)
        tvUnparseable = findViewById(R.id.tv_unparseable)

        findViewById<Button>(R.id.btn_start).setOnClickListener {
            GatewayService.start(this)
            Toast.makeText(this, R.string.service_started, Toast.LENGTH_SHORT).show()
            refreshStatus()
        }
        findViewById<Button>(R.id.btn_stop).setOnClickListener {
            GatewayService.stop(this)
            Toast.makeText(this, R.string.service_stopped, Toast.LENGTH_SHORT).show()
            refreshStatus()
        }
        findViewById<Button>(R.id.btn_permission).setOnClickListener { requestSmsPermission() }
        findViewById<Button>(R.id.btn_battery).setOnClickListener { openBatterySettings() }
        findViewById<Button>(R.id.btn_test).setOnClickListener { sendTest() }
        findViewById<Button>(R.id.btn_retry_now).setOnClickListener { retryNow() }
        findViewById<Button>(R.id.btn_clear_log).setOnClickListener {
            status.clearUnparseableLog()
            refreshStatus()
        }

        // Settings tab
        etServerUrl = findViewById(R.id.et_server_url)
        etSecret = findViewById(R.id.et_secret)
        etShopNumber = findViewById(R.id.et_shop_number)
        cbStartOnBoot = findViewById(R.id.cb_start_on_boot)

        etServerUrl.setText(settings.serverUrl)
        etShopNumber.setText(settings.shopNumber)
        cbStartOnBoot.isChecked = settings.startOnBoot
        // The secret is never shown back — if one is saved, the field shows a placeholder.
        if (settings.hasSecret) etSecret.hint = getString(R.string.secret_saved_hint)

        findViewById<Button>(R.id.btn_save_settings).setOnClickListener { saveSettings() }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                // Back first walks the dashboard's own history, then
                // back to the Dashboard tab, and only then exits.
                if (currentTab == TAB_DASHBOARD && ::webView.isInitialized && webView.canGoBack()) {
                    webView.goBack()
                    return
                }
                if (currentTab != TAB_DASHBOARD) {
                    showTab(TAB_DASHBOARD)
                    return
                }
                isEnabled = false
                onBackPressedDispatcher.onBackPressed()
            }
        })

        showTab(TAB_DASHBOARD)
        requestSmsPermissionIfNeeded()
    }

    override fun onResume() {
        super.onResume()
        if (::webView.isInitialized) webView.onResume()
        refreshStatus()
        refreshHandler.post(refreshRunnable)
    }

    override fun onPause() {
        super.onPause()
        if (::webView.isInitialized) webView.onPause()
        refreshHandler.removeCallbacks(refreshRunnable)
    }

    override fun onDestroy() {
        refreshHandler.removeCallbacks(refreshRunnable)
        if (::webView.isInitialized) {
            (webView.parent as? ViewGroup)?.removeView(webView)
            webView.destroy()
        }
        super.onDestroy()
    }

    // ------------------------------------------------------------------
    // Tabs
    // ------------------------------------------------------------------

    private fun showTab(tab: Int) {
        currentTab = tab
        tabDashboard.visibility = if (tab == TAB_DASHBOARD) View.VISIBLE else View.GONE
        tabPayments.visibility = if (tab == TAB_PAYMENTS) View.VISIBLE else View.GONE
        tabSettings.visibility = if (tab == TAB_SETTINGS) View.VISIBLE else View.GONE
        styleTabButton(btnTabDashboard, tab == TAB_DASHBOARD)
        styleTabButton(btnTabPayments, tab == TAB_PAYMENTS)
        styleTabButton(btnTabSettings, tab == TAB_SETTINGS)
        if (tab == TAB_DASHBOARD) loadDashboard()
        if (tab == TAB_PAYMENTS) refreshStatus()
    }

    private fun styleTabButton(button: Button, selected: Boolean) {
        button.background = ContextCompat.getDrawable(
            this, if (selected) R.drawable.tab_selected else R.drawable.tab_unselected
        )
        button.setTextColor(
            ContextCompat.getColor(
                this, if (selected) R.color.fixo_white else R.color.fixo_dark_red
            )
        )
    }

    // ------------------------------------------------------------------
    // Dashboard (WebView)
    // ------------------------------------------------------------------

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        // The shop session lives in cookies — keep them, including
        // third-party ones, so a signed-in session survives.
        val cookieManager = CookieManager.getInstance()
        cookieManager.setAcceptCookie(true)
        cookieManager.setAcceptThirdPartyCookies(webView, true)

        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.databaseEnabled = true
        webView.settings.useWideViewPort = true
        webView.settings.loadWithOverviewMode = true
        webView.settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(
                view: WebView, request: WebResourceRequest
            ): Boolean {
                val url = request.url
                val host = url.host ?: return false
                // Google blocks OAuth inside any embedded WebView, so the
                // sign-in page's "Continue with Google" button can never
                // work here — offer the phone browser instead. No hack,
                // no user-agent spoofing, no credential handling.
                if (host == "accounts.google.com") {
                    showSignInBanner()
                    return true
                }
                // Anything off the shop opens in the phone browser.
                if (host != "fi.xo.je") {
                    try {
                        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url.toString())))
                    } catch (_: Exception) {
                        // No browser to open it with — stay where we are.
                    }
                    return true
                }
                return false
            }

            override fun onPageFinished(view: WebView, url: String) {
                swipeRefresh.isRefreshing = false
                // A good load clears a load-error banner (the sign-in
                // banner stays until the owner dismisses it).
                if (bannerIsError) hideBanner()
            }

            override fun onReceivedError(
                view: WebView, request: WebResourceRequest, error: WebResourceError
            ) {
                if (request.isForMainFrame) {
                    swipeRefresh.isRefreshing = false
                    showLoadErrorBanner()
                }
            }

            @Suppress("DEPRECATION")
            override fun onReceivedError(
                view: WebView, errorCode: Int, description: String, failingUrl: String
            ) {
                swipeRefresh.isRefreshing = false
                showLoadErrorBanner()
            }

            override fun onReceivedHttpError(
                view: WebView, request: WebResourceRequest, errorResponse: WebResourceResponse
            ) {
                if (request.isForMainFrame && errorResponse.statusCode >= 400) {
                    swipeRefresh.isRefreshing = false
                    showLoadErrorBanner()
                }
            }
        }

        swipeRefresh.setOnRefreshListener { webView.reload() }
        swipeRefresh.setColorSchemeColors(
            ContextCompat.getColor(this, R.color.fixo_primary)
        )
    }

    private fun loadDashboard() {
        if (!webViewLoaded) {
            webView.loadUrl(ADMIN_URL)
            webViewLoaded = true
        }
    }

    private fun showSignInBanner() {
        bannerIsError = false
        tvBannerMessage.text = getString(R.string.signin_blocked_message)
        bannerSignin.visibility = View.VISIBLE
    }

    private fun showLoadErrorBanner() {
        bannerIsError = true
        tvBannerMessage.text = getString(R.string.load_error_message)
        bannerSignin.visibility = View.VISIBLE
    }

    private fun hideBanner() {
        bannerSignin.visibility = View.GONE
    }

    /** Opens the dashboard (or the page currently shown) in the phone browser. */
    private fun openInBrowser() {
        val url = if (::webView.isInitialized && webView.url != null) webView.url!! else ADMIN_URL
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (_: Exception) {
            Toast.makeText(this, R.string.load_error_message, Toast.LENGTH_LONG).show()
        }
    }

    // ------------------------------------------------------------------
    // Permissions / battery (unchanged)
    // ------------------------------------------------------------------

    private fun hasSmsPermission(): Boolean =
        ContextCompat.checkSelfPermission(this, Manifest.permission.RECEIVE_SMS) ==
            PackageManager.PERMISSION_GRANTED

    private fun hasNotificationPermission(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) return true
        return ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED
    }

    private fun requestSmsPermissionIfNeeded() {
        val wanted = mutableListOf(Manifest.permission.RECEIVE_SMS)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            wanted += Manifest.permission.POST_NOTIFICATIONS
        }
        val missing = wanted.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, missing.toTypedArray(), PERMISSION_REQUEST_CODE)
        }
    }

    private fun requestSmsPermission() = requestSmsPermissionIfNeeded()

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PERMISSION_REQUEST_CODE) {
            if (!hasSmsPermission()) {
                Toast.makeText(this, R.string.sms_permission_required, Toast.LENGTH_LONG).show()
            }
            refreshStatus()
        }
    }

    private fun isBatteryOptimisationOff(): Boolean {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        return pm.isIgnoringBatteryOptimizations(packageName)
    }

    /** Opens the system battery-optimisation screen (user picks "Don't optimise"). */
    private fun openBatterySettings() {
        try {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        } catch (e: Exception) {
            startActivity(Intent(Settings.ACTION_SETTINGS))
        }
    }

    // ------------------------------------------------------------------
    // Settings (unchanged)
    // ------------------------------------------------------------------

    private fun saveSettings() {
        val url = etServerUrl.text.toString().trim()
        if (!url.startsWith("https://")) {
            Toast.makeText(this, R.string.url_must_be_https, Toast.LENGTH_LONG).show()
            return
        }
        settings.serverUrl = url
        settings.shopNumber = etShopNumber.text.toString().trim()
        settings.startOnBoot = cbStartOnBoot.isChecked
        val secret = etSecret.text.toString()
        if (secret.isNotBlank()) {
            settings.hmacSecret = secret
            etSecret.setText("")
            etSecret.hint = getString(R.string.secret_saved_hint)
        }
        Toast.makeText(this, R.string.settings_saved, Toast.LENGTH_SHORT).show()
    }

    // ------------------------------------------------------------------
    // Payments tab: test post + retry (unchanged)
    // ------------------------------------------------------------------

    private fun sendTest() {
        if (!settings.hasSecret) {
            Toast.makeText(this, R.string.secret_required, Toast.LENGTH_LONG).show()
            return
        }
        Thread {
            val result = PaymentPoster.postTest(
                settings.serverUrl, settings.hmacSecret, settings.deviceId
            )
            runOnUiThread {
                when (result) {
                    is PaymentPoster.PostResult.Success ->
                        Toast.makeText(this, R.string.test_ok, Toast.LENGTH_LONG).show()
                    is PaymentPoster.PostResult.Failure ->
                        Toast.makeText(this, getString(R.string.test_failed, result.message), Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    /** Force an immediate retry pass (also used after fixing the secret/URL). */
    private fun retryNow() {
        GatewayService.kick(this)
        Thread {
            val s = SettingsManager(applicationContext)
            val st = StatusStore(applicationContext)
            val q = RetryQueue(applicationContext)
            if (!s.hasSecret) {
                runOnUiThread { Toast.makeText(this, R.string.secret_required, Toast.LENGTH_LONG).show() }
                return@Thread
            }
            var posted = 0
            for (pending in q.dueNow()) {
                when (val r = PaymentPoster.postPayment(s.serverUrl, s.hmacSecret, pending.payment)) {
                    is PaymentPoster.PostResult.Success -> {
                        q.remove(pending.payment.smsHash)
                        st.onPosted(pending.payment.trxId)
                        posted++
                    }
                    is PaymentPoster.PostResult.Failure -> {
                        st.onPostFailed(r.message)
                        q.markFailed(pending.payment.smsHash)
                    }
                }
            }
            runOnUiThread {
                Toast.makeText(this, getString(R.string.retry_done, posted), Toast.LENGTH_SHORT).show()
                refreshStatus()
            }
        }.start()
    }

    private fun refreshStatus() {
        val smsOk = hasSmsPermission()
        val notifOk = hasNotificationPermission()
        val batteryOk = isBatteryOptimisationOff()

        tvService.text = getString(
            R.string.service_state,
            if (isServiceRunning()) getString(R.string.running) else getString(R.string.stopped)
        )
        tvPermission.text = getString(
            R.string.permission_state,
            if (smsOk) getString(R.string.granted) else getString(R.string.not_granted),
            if (notifOk) getString(R.string.granted) else getString(R.string.not_granted)
        )
        tvBattery.text = getString(
            R.string.battery_state,
            if (batteryOk) getString(R.string.optimisation_off) else getString(R.string.optimisation_on)
        )
        tvCounts.text = getString(
            R.string.counts,
            status.countReceived(), status.countPosted(), status.countFailed()
        )
        tvLastSms.text = getString(R.string.last_sms, status.lastSms())
        tvLastPost.text = getString(R.string.last_post, status.lastPost())
        tvLastError.text = getString(R.string.last_error, status.lastError())
        tvPending.text = getString(R.string.pending_count, queue.count())
        tvDeviceId.text = getString(R.string.device_id, settings.deviceId)

        val log = status.unparseableLog()
        tvUnparseable.text = if (log.isEmpty()) {
            getString(R.string.unparseable_empty)
        } else {
            log.take(5).joinToString("\n\n") {
                "${it.time} · ${it.provider} · ${it.reason}\n${it.body}"
            }
        }

        // Warn loudly when the setup is incomplete.
        if (!smsOk || !batteryOk || !settings.hasSecret) {
            tvService.setTextColor(0xFFB00020.toInt())
        } else {
            tvService.setTextColor(0xFF1B5E20.toInt())
        }
    }

    /** Best-effort check: is our foreground service currently running? */
    private fun isServiceRunning(): Boolean {
        @Suppress("DEPRECATION")
        val am = getSystemService(ACTIVITY_SERVICE) as android.app.ActivityManager
        @Suppress("DEPRECATION")
        return am.getRunningServices(Int.MAX_VALUE).any {
            it.service.className == GatewayService::class.java.name
        }
    }
}
