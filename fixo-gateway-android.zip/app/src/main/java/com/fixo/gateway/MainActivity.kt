package com.fixo.gateway

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

/**
 * Tab host: Payments (SMS status + payment history) + Settings.
 *
 * v1.2.0: the Dashboard tab (WebView of the shop admin) was REMOVED at
 * the owner's request (2026-11-19) — the app is a Paymently-style relay
 * again, no admin inside it. Shop admin sign-in happens in the phone
 * browser, not in the app. The app has no WebView at all now.
 *
 *  - Payments: is the service running, is SMS permission granted, is
 *    battery optimisation off, today's counts, last SMS, last
 *    successful post, last error, pending queue, test post, retry,
 *    and the recent-payments list (method, sender, amount, TrxID,
 *    time, status).
 *  - Settings: server URL + HMAC secret (entered once, stored
 *    encrypted), shop number, start on boot.
 *
 * The SMS relay itself (SmsReceiver / SmsParser / PaymentPoster /
 * RetryQueue / GatewayService) is untouched by the UI — it runs in the
 * background service whether or not this screen is open.
 */
class MainActivity : AppCompatActivity() {

    companion object {
        private const val PERMISSION_REQUEST_CODE = 100
        private const val TAB_PAYMENTS = 0
        private const val TAB_SETTINGS = 1
    }

    private lateinit var settings: SettingsManager
    private lateinit var status: StatusStore
    private lateinit var queue: RetryQueue
    private lateinit var history: PaymentHistory

    // Tabs
    private lateinit var tabPayments: View
    private lateinit var tabSettings: View
    private lateinit var btnTabPayments: Button
    private lateinit var btnTabSettings: Button
    private var currentTab = TAB_PAYMENTS

    // Payments tab
    private lateinit var tvService: TextView
    private lateinit var tvPermission: TextView
    private lateinit var tvBattery: TextView
    private lateinit var tvCounts: TextView
    private lateinit var tvLastSms: TextView
    private lateinit var tvLastPost: TextView
    private lateinit var tvLastError: TextView
    private lateinit var tvPending: TextView
    private lateinit var tvDeviceId: TextView
    private lateinit var tvUnparseable: TextView
    private lateinit var historyContainer: LinearLayout
    private lateinit var tvHistoryEmpty: TextView
    private var lastHistorySignature = ""

    // Settings tab
    private lateinit var etServerUrl: EditText
    private lateinit var etSecret: EditText
    private lateinit var etShopNumber: EditText
    private lateinit var cbStartOnBoot: CheckBox

    private val refreshHandler = Handler(Looper.getMainLooper())
    private val refreshRunnable = object : Runnable {
        override fun run() {
            refreshStatus()
            refreshHandler.postDelayed(this, 5_000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        settings = SettingsManager(this)
        status = StatusStore(this)
        queue = RetryQueue(this)
        history = PaymentHistory(this)

        // Tabs
        tabPayments = findViewById(R.id.tab_payments)
        tabSettings = findViewById(R.id.tab_settings)
        btnTabPayments = findViewById(R.id.btn_tab_payments)
        btnTabSettings = findViewById(R.id.btn_tab_settings)
        btnTabPayments.setOnClickListener { showTab(TAB_PAYMENTS) }
        btnTabSettings.setOnClickListener { showTab(TAB_SETTINGS) }

        // Payments tab
        tvService = findViewById(R.id.tv_service)
        tvPermission = findViewById(R.id.tv_permission)
        tvBattery = findViewById(R.id.tv_battery)
        tvCounts = findViewById(R.id.tv_counts)
        tvLastSms = findViewById(R.id.tv_last_sms)
        tvLastPost = findViewById(R.id.tv_last_post)
        tvLastError = findViewById(R.id.tv_last_error)
        tvPending = findViewById(R.id.tv_pending)
        tvDeviceId = findViewById(R.id.tv_device_id)
        tvUnparseable = findViewById(R.id.tv_unparseable)
        historyContainer = findViewById(R.id.history_container)
        tvHistoryEmpty = findViewById(R.id.tv_history_empty)

        findViewById<Button>(R.id.btn_start).setOnClickListener {
            GatewayService.start(this)
            Toast.makeText(this, R.string.service_started, Toast.LENGTH_SHORT).show()
            refreshStatus()
        }
        findViewById<Button>(R.id.btn_stop).setOnClickListener {
            GatewayService.stop(this)
            Toast.makeText(this, R.string.service_stopped, Toast.LENGTH_SHORT).show()
            refreshStatus()
        }
        findViewById<Button>(R.id.btn_permission).setOnClickListener { requestSmsPermission() }
        findViewById<Button>(R.id.btn_battery).setOnClickListener { openBatterySettings() }
        findViewById<Button>(R.id.btn_test).setOnClickListener { sendTest() }
        findViewById<Button>(R.id.btn_retry_now).setOnClickListener { retryNow() }
        findViewById<Button>(R.id.btn_clear_log).setOnClickListener {
            status.clearUnparseableLog()
            refreshStatus()
        }

        // Settings tab
        etServerUrl = findViewById(R.id.et_server_url)
        etSecret = findViewById(R.id.et_secret)
        etShopNumber = findViewById(R.id.et_shop_number)
        cbStartOnBoot = findViewById(R.id.cb_start_on_boot)

        etServerUrl.setText(settings.serverUrl)
        etShopNumber.setText(settings.shopNumber)
        cbStartOnBoot.isChecked = settings.startOnBoot
        // The secret is never shown back — if one is saved, the field shows a placeholder.
        if (settings.hasSecret) etSecret.hint = getString(R.string.secret_saved_hint)

        findViewById<Button>(R.id.btn_save_settings).setOnClickListener { saveSettings() }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                // Back from Settings returns to Payments; back from
                // Payments exits the app.
                if (currentTab != TAB_PAYMENTS) {
                    showTab(TAB_PAYMENTS)
                    return
                }
                isEnabled = false
                onBackPressedDispatcher.onBackPressed()
            }
        })

        showTab(TAB_PAYMENTS)
        requestSmsPermissionIfNeeded()
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
        refreshHandler.post(refreshRunnable)
    }

    override fun onPause() {
        super.onPause()
        refreshHandler.removeCallbacks(refreshRunnable)
    }

    override fun onDestroy() {
        refreshHandler.removeCallbacks(refreshRunnable)
        super.onDestroy()
    }

    // ------------------------------------------------------------------
    // Tabs
    // ------------------------------------------------------------------

    private fun showTab(tab: Int) {
        currentTab = tab
        tabPayments.visibility = if (tab == TAB_PAYMENTS) View.VISIBLE else View.GONE
        tabSettings.visibility = if (tab == TAB_SETTINGS) View.VISIBLE else View.GONE
        styleTabButton(btnTabPayments, tab == TAB_PAYMENTS)
        styleTabButton(btnTabSettings, tab == TAB_SETTINGS)
        if (tab == TAB_PAYMENTS) refreshStatus()
    }

    private fun styleTabButton(button: Button, selected: Boolean) {
        button.background = ContextCompat.getDrawable(
            this, if (selected) R.drawable.tab_selected else R.drawable.tab_unselected
        )
        button.setTextColor(
            ContextCompat.getColor(
                this, if (selected) R.color.fixo_white else R.color.fixo_dark_red
            )
        )
    }

    // ------------------------------------------------------------------
    // Permissions / battery (unchanged)
    // ------------------------------------------------------------------

    private fun hasSmsPermission(): Boolean =
        ContextCompat.checkSelfPermission(this, Manifest.permission.RECEIVE_SMS) ==
            PackageManager.PERMISSION_GRANTED

    private fun hasNotificationPermission(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) return true
        return ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED
    }

    private fun requestSmsPermissionIfNeeded() {
        val wanted = mutableListOf(Manifest.permission.RECEIVE_SMS)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            wanted += Manifest.permission.POST_NOTIFICATIONS
        }
        val missing = wanted.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, missing.toTypedArray(), PERMISSION_REQUEST_CODE)
        }
    }

    private fun requestSmsPermission() = requestSmsPermissionIfNeeded()

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PERMISSION_REQUEST_CODE) {
            if (!hasSmsPermission()) {
                Toast.makeText(this, R.string.sms_permission_required, Toast.LENGTH_LONG).show()
            }
            refreshStatus()
        }
    }

    private fun isBatteryOptimisationOff(): Boolean {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        return pm.isIgnoringBatteryOptimizations(packageName)
    }

    /** Opens the system battery-optimisation screen (user picks "Don't optimise"). */
    private fun openBatterySettings() {
        try {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        } catch (e: Exception) {
            startActivity(Intent(Settings.ACTION_SETTINGS))
        }
    }

    // ------------------------------------------------------------------
    // Settings (unchanged)
    // ------------------------------------------------------------------

    private fun saveSettings() {
        val url = etServerUrl.text.toString().trim()
        if (!url.startsWith("https://")) {
            Toast.makeText(this, R.string.url_must_be_https, Toast.LENGTH_LONG).show()
            return
        }
        settings.serverUrl = url
        settings.shopNumber = etShopNumber.text.toString().trim()
        settings.startOnBoot = cbStartOnBoot.isChecked
        val secret = etSecret.text.toString()
        if (secret.isNotBlank()) {
            settings.hmacSecret = secret
            etSecret.setText("")
            etSecret.hint = getString(R.string.secret_saved_hint)
        }
        Toast.makeText(this, R.string.settings_saved, Toast.LENGTH_SHORT).show()
    }

    // ------------------------------------------------------------------
    // Payments tab: test post + retry (unchanged)
    // ------------------------------------------------------------------

    private fun sendTest() {
        if (!settings.hasSecret) {
            Toast.makeText(this, R.string.secret_required, Toast.LENGTH_LONG).show()
            return
        }
        Thread {
            val result = PaymentPoster.postTest(
                settings.serverUrl, settings.hmacSecret, settings.deviceId
            )
            runOnUiThread {
                when (result) {
                    is PaymentPoster.PostResult.Success ->
                        Toast.makeText(this, R.string.test_ok, Toast.LENGTH_LONG).show()
                    is PaymentPoster.PostResult.Failure ->
                        Toast.makeText(this, getString(R.string.test_failed, result.message), Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    /** Force an immediate retry pass (also used after fixing the secret/URL). */
    private fun retryNow() {
        GatewayService.kick(this)
        Thread {
            val s = SettingsManager(applicationContext)
            val st = StatusStore(applicationContext)
            val q = RetryQueue(applicationContext)
            if (!s.hasSecret) {
                runOnUiThread { Toast.makeText(this, R.string.secret_required, Toast.LENGTH_LONG).show() }
                return@Thread
            }
            var posted = 0
            for (pending in q.dueNow()) {
                when (val r = PaymentPoster.postPayment(s.serverUrl, s.hmacSecret, pending.payment)) {
                    is PaymentPoster.PostResult.Success -> {
                        q.remove(pending.payment.smsHash)
                        st.onPosted(pending.payment.trxId)
                        posted++
                    }
                    is PaymentPoster.PostResult.Failure -> {
                        st.onPostFailed(r.message)
                        q.markFailed(pending.payment.smsHash)
                    }
                }
            }
            runOnUiThread {
                Toast.makeText(this, getString(R.string.retry_done, posted), Toast.LENGTH_SHORT).show()
                refreshStatus()
            }
        }.start()
    }

    private fun refreshStatus() {
        val smsOk = hasSmsPermission()
        val notifOk = hasNotificationPermission()
        val batteryOk = isBatteryOptimisationOff()

        tvService.text = getString(
            R.string.service_state,
            if (isServiceRunning()) getString(R.string.running) else getString(R.string.stopped)
        )
        tvPermission.text = getString(
            R.string.permission_state,
            if (smsOk) getString(R.string.granted) else getString(R.string.not_granted),
            if (notifOk) getString(R.string.granted) else getString(R.string.not_granted)
        )
        tvBattery.text = getString(
            R.string.battery_state,
            if (batteryOk) getString(R.string.optimisation_off) else getString(R.string.optimisation_on)
        )
        tvCounts.text = getString(
            R.string.counts,
            status.countReceived(), status.countPosted(), status.countFailed()
        )
        tvLastSms.text = getString(R.string.last_sms, status.lastSms())
        tvLastPost.text = getString(R.string.last_post, status.lastPost())
        tvLastError.text = getString(R.string.last_error, status.lastError())
        tvPending.text = getString(R.string.pending_count, queue.count())
        tvDeviceId.text = getString(R.string.device_id, settings.deviceId)

        val log = status.unparseableLog()
        tvUnparseable.text = if (log.isEmpty()) {
            getString(R.string.unparseable_empty)
        } else {
            log.take(5).joinToString("\n\n") {
                "${it.time} · ${it.provider} · ${it.reason}\n${it.body}"
            }
        }

        // Warn loudly when the setup is incomplete.
        if (!smsOk || !batteryOk || !settings.hasSecret) {
            tvService.setTextColor(0xFFB00020.toInt())
        } else {
            tvService.setTextColor(0xFF1B5E20.toInt())
        }

        renderHistory()
    }

    // ------------------------------------------------------------------
    // Payments tab: recent-payments list (v1.2.0)
    // ------------------------------------------------------------------

    /** Rebuilds the history list only when it actually changed. */
    private fun renderHistory() {
        val entries = history.recent(50)
        val signature = entries.joinToString("|") { it.smsHash + ":" + it.status }
        if (signature == lastHistorySignature) return
        lastHistorySignature = signature

        tvHistoryEmpty.visibility = if (entries.isEmpty()) View.VISIBLE else View.GONE
        historyContainer.removeAllViews()
        for ((index, e) in entries.withIndex()) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(0, 10, 0, 10)
            }
            val top = TextView(this).apply {
                text = "${displayProvider(e.provider)}  ·  ৳${displayAmount(e.amount)}"
                textSize = 15f
                setTypeface(null, android.graphics.Typeface.BOLD)
                setTextColor(ContextCompat.getColor(this@MainActivity, R.color.fixo_dark_red))
            }
            val statusText = when (e.status) {
                PaymentHistory.STATUS_POSTED -> "Posted"
                PaymentHistory.STATUS_FAILED -> "Failed"
                else -> "Pending"
            }
            val statusColor = when (e.status) {
                PaymentHistory.STATUS_POSTED -> 0xFF1B5E20.toInt()
                PaymentHistory.STATUS_FAILED -> 0xFFB00020.toInt()
                else -> 0xFFB26A00.toInt()
            }
            val bottom = TextView(this).apply {
                text = "${e.sender}  ·  ${shortTrx(e.trxId)}  ·  ${displayTime(e.receivedAt)}  ·  $statusText"
                textSize = 13f
                setTextColor(statusColor)
            }
            row.addView(top)
            row.addView(bottom)
            historyContainer.addView(row)
            if (index < entries.size - 1) {
                val divider = View(this).apply {
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT, 1
                    )
                    setBackgroundColor(0xFFE7DCD5.toInt())
                }
                historyContainer.addView(divider)
            }
        }
    }

    private fun displayProvider(provider: String): String = when (provider) {
        "bkash" -> "bKash"
        "nagad" -> "Nagad"
        "rocket" -> "Rocket"
        "upay" -> "Upay"
        else -> provider.replaceFirstChar { it.uppercase() }
    }

    /** "49.00" -> "49"; "1000.50" stays "1000.50". */
    private fun displayAmount(amount: String): String = amount.removeSuffix(".00")

    /** "9HX7K2LMNP" -> "9HX7K2…". */
    private fun shortTrx(trxId: String): String =
        if (trxId.length > 8) trxId.take(6) + "…" else trxId

    /** "2026-11-19T13:30:00Z" -> "2026-11-19 13:30". */
    private fun displayTime(receivedAt: String): String =
        if (receivedAt.length >= 16) receivedAt.take(16).replace('T', ' ') else receivedAt

    /** Best-effort check: is our foreground service currently running? */
    private fun isServiceRunning(): Boolean {
        @Suppress("DEPRECATION")
        val am = getSystemService(ACTIVITY_SERVICE) as android.app.ActivityManager
        @Suppress("DEPRECATION")
        return am.getRunningServices(Int.MAX_VALUE).any {
            it.service.className == GatewayService::class.java.name
        }
    }
}
