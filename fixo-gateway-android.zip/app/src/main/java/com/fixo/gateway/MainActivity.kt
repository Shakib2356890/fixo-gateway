package com.fixo.gateway

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

/**
 * v1.2.2: cleanup at the owner's request — "too much unnecessary text".
 * The Payments tab is now ONLY the header (Fixo O-check, live dot,
 * Received/Posted/Pending chips), the Send test button, and the Recent
 * payments list. Gone: the whole service-status card, the Failed-today
 * line, the Unparseable-messages section, the Clear-log button, the
 * battery button, and the Start/Stop/Retry/permission buttons (the
 * relay service starts itself when the app opens and at boot).
 * Settings is now ONLY the start-on-boot switch + the version line.
 * The server URL and shop number are fixed constants (SettingsManager)
 * — no fields for them anywhere. The HMAC secret is never shown and
 * never asked for: it is read from the encrypted store the owner
 * already saved. ONLY a fresh install with no secret stored shows a
 * single secret field on Settings, once.
 *
 * v1.2.1: MODERN redesign — dark-red gradient header, pulsing live
 * dot, stat chips, prominent Send test button, history rows as modern
 * cards, pill tab bar. UI only; the SMS relay, poster, queue, history
 * store and settings are untouched by the UI.
 * Tab host: Payments (status + payment history) + Settings.
 *
 * The SMS relay itself (SmsReceiver / SmsParser / PaymentPoster /
 * RetryQueue / GatewayService) is untouched by the UI — it runs in the
 * background service whether or not this screen is open.
 */
class MainActivity : AppCompatActivity() {

    companion object {
        private const val PERMISSION_REQUEST_CODE = 100
        private const val TAB_PAYMENTS = 0
        private const val TAB_SETTINGS = 1
    }

    private lateinit var settings: SettingsManager
    private lateinit var status: StatusStore
    private lateinit var queue: RetryQueue
    private lateinit var history: PaymentHistory

    // Tabs
    private lateinit var tabPayments: View
    private lateinit var tabSettings: View
    private lateinit var btnTabPayments: Button
    private lateinit var btnTabSettings: Button
    private var currentTab = TAB_PAYMENTS

    // Header (v1.2.1 modern redesign)
    private lateinit var dotLive: View
    private lateinit var tvLiveLabel: TextView
    private lateinit var tvStatReceived: TextView
    private lateinit var tvStatPosted: TextView
    private lateinit var tvStatPending: TextView
    private lateinit var pulseAnim: Animation

    // Payments tab
    private lateinit var historyContainer: LinearLayout
    private lateinit var tvHistoryEmpty: TextView
    private var lastHistorySignature = ""

    // Settings tab (v1.2.2: boot switch + version + fresh-install secret only)
    private lateinit var secretCard: LinearLayout
    private lateinit var etSecret: EditText
    private lateinit var cbStartOnBoot: CheckBox

    private val refreshHandler = Handler(Looper.getMainLooper())
    private val refreshRunnable = object : Runnable {
        override fun run() {
            refreshStatus()
            refreshHandler.postDelayed(this, 5_000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        settings = SettingsManager(this)
        status = StatusStore(this)
        queue = RetryQueue(this)
        history = PaymentHistory(this)

        // Tabs
        tabPayments = findViewById(R.id.tab_payments)
        tabSettings = findViewById(R.id.tab_settings)
        btnTabPayments = findViewById(R.id.btn_tab_payments)
        btnTabSettings = findViewById(R.id.btn_tab_settings)
        btnTabPayments.setOnClickListener { showTab(TAB_PAYMENTS) }
        btnTabSettings.setOnClickListener { showTab(TAB_SETTINGS) }

        // Header (v1.2.1)
        dotLive = findViewById(R.id.dot_live)
        tvLiveLabel = findViewById(R.id.tv_live_label)
        tvStatReceived = findViewById(R.id.tv_stat_received)
        tvStatPosted = findViewById(R.id.tv_stat_posted)
        tvStatPending = findViewById(R.id.tv_stat_pending)
        pulseAnim = AnimationUtils.loadAnimation(this, R.anim.pulse_dot)

        // Payments tab
        historyContainer = findViewById(R.id.history_container)
        tvHistoryEmpty = findViewById(R.id.tv_history_empty)
        findViewById<Button>(R.id.btn_test).setOnClickListener { sendTest() }

        // Settings tab — the secret field shows ONLY on a fresh install
        // with no secret stored yet; normally it never appears.
        secretCard = findViewById(R.id.secret_card)
        etSecret = findViewById(R.id.et_secret)
        cbStartOnBoot = findViewById(R.id.cb_start_on_boot)
        cbStartOnBoot.isChecked = settings.startOnBoot
        secretCard.visibility = if (settings.hasSecret) View.GONE else View.VISIBLE

        findViewById<Button>(R.id.btn_save_settings).setOnClickListener { saveSettings() }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                // Back from Settings returns to Payments; back from
                // Payments exits the app.
                if (currentTab != TAB_PAYMENTS) {
                    showTab(TAB_PAYMENTS)
                    return
                }
                isEnabled = false
                onBackPressedDispatcher.onBackPressed()
            }
        })

        showTab(TAB_PAYMENTS)
        requestSmsPermissionIfNeeded()
        // No Start button anymore — the relay service starts itself
        // when the app opens (and at boot). Silent: nothing to report
        // when it is already running.
        if (!isServiceRunning()) GatewayService.start(this)
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
        refreshHandler.post(refreshRunnable)
    }

    override fun onPause() {
        super.onPause()
        refreshHandler.removeCallbacks(refreshRunnable)
    }

    override fun onDestroy() {
        refreshHandler.removeCallbacks(refreshRunnable)
        super.onDestroy()
    }

    // ------------------------------------------------------------------
    // Tabs
    // ------------------------------------------------------------------

    private fun showTab(tab: Int) {
        currentTab = tab
        tabPayments.visibility = if (tab == TAB_PAYMENTS) View.VISIBLE else View.GONE
        tabSettings.visibility = if (tab == TAB_SETTINGS) View.VISIBLE else View.GONE
        styleTabButton(btnTabPayments, tab == TAB_PAYMENTS)
        styleTabButton(btnTabSettings, tab == TAB_SETTINGS)
        if (tab == TAB_PAYMENTS) refreshStatus()
    }

    private fun styleTabButton(button: Button, selected: Boolean) {
        button.background = ContextCompat.getDrawable(
            this, if (selected) R.drawable.tab_selected else R.drawable.tab_unselected
        )
        button.setTextColor(
            ContextCompat.getColor(
                this, if (selected) R.color.fixo_white else R.color.fixo_dark_red
            )
        )
    }

    // ------------------------------------------------------------------
    // Permissions (unchanged)
    // ------------------------------------------------------------------

    private fun hasSmsPermission(): Boolean =
        ContextCompat.checkSelfPermission(this, Manifest.permission.RECEIVE_SMS) ==
            PackageManager.PERMISSION_GRANTED

    private fun requestSmsPermissionIfNeeded() {
        val wanted = mutableListOf(Manifest.permission.RECEIVE_SMS)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            wanted += Manifest.permission.POST_NOTIFICATIONS
        }
        val missing = wanted.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, missing.toTypedArray(), PERMISSION_REQUEST_CODE)
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PERMISSION_REQUEST_CODE) {
            if (!hasSmsPermission()) {
                Toast.makeText(this, R.string.sms_permission_required, Toast.LENGTH_LONG).show()
            }
            refreshStatus()
        }
    }

    // ------------------------------------------------------------------
    // Settings (v1.2.2: boot switch + fresh-install secret only)
    // ------------------------------------------------------------------

    private fun saveSettings() {
        settings.startOnBoot = cbStartOnBoot.isChecked
        val secret = etSecret.text.toString()
        if (secret.isNotBlank()) {
            settings.hmacSecret = secret
            etSecret.setText("")
            // Saved once — the field never shows again.
            secretCard.visibility = View.GONE
        }
        Toast.makeText(this, R.string.settings_saved, Toast.LENGTH_SHORT).show()
    }

    // ------------------------------------------------------------------
    // Payments tab: test post (unchanged)
    // ------------------------------------------------------------------

    private fun sendTest() {
        if (!settings.hasSecret) {
            Toast.makeText(this, R.string.secret_required, Toast.LENGTH_LONG).show()
            return
        }
        Thread {
            val result = PaymentPoster.postTest(
                settings.serverUrl, settings.hmacSecret, settings.deviceId
            )
            runOnUiThread {
                when (result) {
                    is PaymentPoster.PostResult.Success ->
                        Toast.makeText(this, R.string.test_ok, Toast.LENGTH_LONG).show()
                    is PaymentPoster.PostResult.Failure ->
                        Toast.makeText(this, getString(R.string.test_failed, result.message), Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun refreshStatus() {
        val running = isServiceRunning()
        // Header stat chips (v1.2.1): today's counts at a glance.
        tvStatReceived.text = status.countReceived().toString()
        tvStatPosted.text = status.countPosted().toString()
        tvStatPending.text = queue.count().toString()
        updateLiveDot(running)
        renderHistory()
    }

    // ------------------------------------------------------------------
    // Header live indicator (v1.2.1, UI only)
    // ------------------------------------------------------------------

    /** Green pulsing dot + "Listening" while the service runs; a
     *  static soft-red dot + "Stopped" otherwise. */
    private fun updateLiveDot(running: Boolean) {
        if (running) {
            dotLive.setBackgroundResource(R.drawable.dot_live)
            if (dotLive.animation == null) dotLive.startAnimation(pulseAnim)
            tvLiveLabel.setText(R.string.listening)
        } else {
            dotLive.clearAnimation()
            dotLive.setBackgroundResource(R.drawable.dot_stopped)
            tvLiveLabel.setText(R.string.stopped_label)
        }
    }

    // ------------------------------------------------------------------
    // Payments tab: recent-payments list (v1.2.0)
    // ------------------------------------------------------------------

    /** Rebuilds the history list only when it actually changed. */
    private fun renderHistory() {
        val entries = history.recent(50)
        val signature = entries.joinToString("|") { it.smsHash + ":" + it.status }
        if (signature == lastHistorySignature) return
        lastHistorySignature = signature

        tvHistoryEmpty.visibility = if (entries.isEmpty()) View.VISIBLE else View.GONE
        historyContainer.removeAllViews()
        val density = resources.displayMetrics.density
        for (e in entries) {
            // Modern card row (v1.2.1): glass card, provider + big amount
            // on the top row, sender/TrxID/time below, status chip last.
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = ContextCompat.getDrawable(
                    this@MainActivity, R.drawable.card_bg
                )
                setPadding(
                    (16 * density).toInt(), (12 * density).toInt(),
                    (16 * density).toInt(), (12 * density).toInt()
                )
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { bottomMargin = (10 * density).toInt() }
            }
            val topRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
            }
            val providerView = TextView(this).apply {
                text = displayProvider(e.provider)
                textSize = 15f
                setTypeface(null, android.graphics.Typeface.BOLD)
                setTextColor(ContextCompat.getColor(this@MainActivity, R.color.fixo_dark_red))
                layoutParams = LinearLayout.LayoutParams(
                    0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f
                )
            }
            val amountView = TextView(this).apply {
                text = "৳${displayAmount(e.amount)}"
                textSize = 18f
                setTypeface(null, android.graphics.Typeface.BOLD)
                setTextColor(ContextCompat.getColor(this@MainActivity, R.color.fixo_dark_red))
            }
            topRow.addView(providerView)
            topRow.addView(amountView)
            val statusText = when (e.status) {
                PaymentHistory.STATUS_POSTED -> "Posted"
                PaymentHistory.STATUS_FAILED -> "Failed"
                else -> "Pending"
            }
            val statusColor = when (e.status) {
                PaymentHistory.STATUS_POSTED -> 0xFF1B5E20.toInt()
                PaymentHistory.STATUS_FAILED -> 0xFFB00020.toInt()
                else -> 0xFFB26A00.toInt()
            }
            val bottom = TextView(this).apply {
                text = "${e.sender}  ·  ${shortTrx(e.trxId)}  ·  ${displayTime(e.receivedAt)}"
                textSize = 13f
                setTextColor(ContextCompat.getColor(this@MainActivity, R.color.fixo_text))
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { topMargin = (6 * density).toInt() }
            }
            // Glass status chip: translucent fill + matching border (website style).
            // Padding/margin in dp so the chip reads the same on small phones.
            val chip = TextView(this).apply {
                text = statusText
                textSize = 12f
                setTypeface(null, android.graphics.Typeface.BOLD)
                setTextColor(statusColor)
                setPadding(
                    (12 * density).toInt(), (4 * density).toInt(),
                    (12 * density).toInt(), (4 * density).toInt()
                )
                background = ContextCompat.getDrawable(
                    this@MainActivity,
                    when (e.status) {
                        PaymentHistory.STATUS_POSTED -> R.drawable.pill_posted
                        PaymentHistory.STATUS_FAILED -> R.drawable.pill_failed
                        else -> R.drawable.pill_pending
                    }
                )
            }
            val chipParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = (8 * density).toInt() }
            row.addView(topRow)
            row.addView(bottom)
            row.addView(chip, chipParams)
            historyContainer.addView(row)
        }
    }

    private fun displayProvider(provider: String): String = when (provider) {
        "bkash" -> "bKash"
        "nagad" -> "Nagad"
        "rocket" -> "Rocket"
        "upay" -> "Upay"
        else -> provider.replaceFirstChar { it.uppercase() }
    }

    /** "49.00" -> "49"; "1000.50" stays "1000.50". */
    private fun displayAmount(amount: String): String = amount.removeSuffix(".00")

    /** "9HX7K2LMNP" -> "9HX7K2…". */
    private fun shortTrx(trxId: String): String =
        if (trxId.length > 8) trxId.take(6) + "…" else trxId

    /** "2026-11-19T13:30:00Z" -> "2026-11-19 13:30". */
    private fun displayTime(receivedAt: String): String =
        if (receivedAt.length >= 16) receivedAt.take(16).replace('T', ' ') else receivedAt

    /** Best-effort check: is our foreground service currently running? */
    private fun isServiceRunning(): Boolean {
        @Suppress("DEPRECATION")
        val am = getSystemService(ACTIVITY_SERVICE) as android.app.ActivityManager
        @Suppress("DEPRECATION")
        return am.getRunningServices(Int.MAX_VALUE).any {
            it.service.className == GatewayService::class.java.name
        }
    }
}
