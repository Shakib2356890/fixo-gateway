package com.fixo.gateway

import android.app.Activity
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout

/**
 * Fetches the InfinityFree anti-bot session cookie with a hidden
 * WebView (v1.2.4).
 *
 * Why: InfinityFree serves a JavaScript challenge page (HTTP 200
 * HTML) to non-browser clients. HttpURLConnection cannot run
 * JavaScript, so it never receives the anti-bot cookie and every
 * POST is intercepted — the v1.2.3 Send test failed with
 * "unexpected response (HTTP 200)" for exactly this reason. A
 * WebView runs the challenge like a real browser, the host sets its
 * cookie, and we then send that cookie with every POST
 * (PaymentPoster) so requests reach verify.php.
 *
 * The WebView is invisible (1x1, INVISIBLE) and is removed +
 * destroyed as soon as the fetch finishes. The callback is invoked
 * exactly once, on the main thread: true = a non-empty cookie was
 * saved to SettingsManager.botCookie, false = no cookie / error /
 * timeout (30 s).
 */
object BotCookieFetcher {

    private const val COOKIE_URL = "https://fi.xo.je/"
    private const val TIMEOUT_MS = 30_000L
    private const val CHECK_DELAY_MS = 1_500L

    /**
     * Fetch the cookie. Must be called from the main thread (WebView
     * requires it); if called from another thread it re-posts itself
     * to the main thread and returns.
     */
    operator fun invoke(activity: Activity, onDone: (Boolean) -> Unit) {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            Handler(Looper.getMainLooper()).post { invoke(activity, onDone) }
            return
        }
        if (activity.isFinishing || activity.isDestroyed) {
            onDone(false)
            return
        }
        Fetcher(activity, onDone).start()
    }

    private class Fetcher(
        private val activity: Activity,
        private val onDone: (Boolean) -> Unit
    ) {
        private val handler = Handler(Looper.getMainLooper())
        private var finished = false
        private var webView: WebView? = null
        private var container: FrameLayout? = null

        private val timeoutRunnable = Runnable { finish(false) }

        /** Re-checks the cookie until it appears or the timeout fires. */
        private val checkRunnable = object : Runnable {
            override fun run() {
                if (finished) return
                if (readCookie()) {
                    finish(true)
                    return
                }
                handler.postDelayed(this, CHECK_DELAY_MS)
            }
        }

        fun start() {
            val cookieManager = CookieManager.getInstance()
            cookieManager.setAcceptCookie(true)

            val webView = WebView(activity)
            this.webView = webView
            webView.settings.javaScriptEnabled = true
            webView.settings.domStorageEnabled = true
            try {
                CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)
            } catch (ignored: Exception) {
            }
            webView.webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView, url: String) {
                    // The challenge JS runs after load; start polling
                    // for the cookie it sets.
                    handler.removeCallbacks(checkRunnable)
                    handler.postDelayed(checkRunnable, CHECK_DELAY_MS)
                }

                override fun onReceivedError(
                    view: WebView,
                    request: WebResourceRequest,
                    error: WebResourceError
                ) {
                    // A load error means no cookie is coming from this
                    // page; finish failed (unless the cookie arrived
                    // first — readCookie below guards that).
                    if (!readCookie()) finish(false)
                }
            }

            // Invisible 1x1 container attached to the window — a
            // WebView must be attached to load. Removed on finish.
            val container = FrameLayout(activity).apply {
                layoutParams = ViewGroup.LayoutParams(1, 1)
                visibility = View.INVISIBLE
            }
            this.container = container
            container.addView(
                webView,
                ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
            )
            (activity.findViewById<ViewGroup>(android.R.id.content)).addView(container)

            handler.postDelayed(timeoutRunnable, TIMEOUT_MS)
            webView.loadUrl(COOKIE_URL)
            // In case onPageFinished never fires, poll anyway.
            handler.postDelayed(checkRunnable, CHECK_DELAY_MS)
        }

        /** Reads the cookie for the shop domain; saves it if present. */
        private fun readCookie(): Boolean {
            return try {
                val cookie = CookieManager.getInstance().getCookie(COOKIE_URL) ?: ""
                if (cookie.isNotBlank()) {
                    SettingsManager(activity).botCookie = cookie
                    true
                } else {
                    false
                }
            } catch (ignored: Exception) {
                false
            }
        }

        private fun finish(success: Boolean) {
            if (finished) return
            finished = true
            handler.removeCallbacks(timeoutRunnable)
            handler.removeCallbacks(checkRunnable)
            try {
                webView?.stopLoading()
            } catch (ignored: Exception) {
            }
            try {
                container?.let { parent ->
                    (activity.findViewById<ViewGroup>(android.R.id.content)).removeView(parent)
                }
            } catch (ignored: Exception) {
            }
            try {
                webView?.destroy()
            } catch (ignored: Exception) {
            }
            webView = null
            container = null
            onDone(success)
        }
    }
}
