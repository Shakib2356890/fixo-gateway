package com.fixo.gateway

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** After a reboot, restart the gateway service (if the owner enabled it). */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val settings = SettingsManager(context.applicationContext)
        if (settings.startOnBoot) {
            GatewayService.start(context.applicationContext)
        }
    }
}
