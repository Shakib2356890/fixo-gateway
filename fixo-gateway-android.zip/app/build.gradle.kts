plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.fixo.gateway"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.fixo.gateway"
        minSdk = 26
        targetSdk = 33
        versionCode = 8
        versionName = "1.2.4"
        // v1.2.3: HMAC secret baked in at build time from the Gradle
        // property fixoHmacSecret (GitHub Actions secret FIXO_HMAC_SECRET).
        // Empty string when the property is absent (local build).
        buildConfigField("String", "HMAC_SECRET", "\"${project.findProperty("fixoHmacSecret") ?: ""}\"")
    }

    buildFeatures {
        buildConfig = true
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
    // EncryptedSharedPreferences — the HMAC secret lives here, never in code.
    // NOTE: MasterKey (Builder API) does NOT exist in security-crypto 1.0.0 —
    // it arrived in 1.1.0-alpha01. 1.1.0-alpha06 is the version Google's own
    // docs use for MasterKey. Do NOT downgrade to 1.0.0 (build breaks).
    implementation("androidx.security:security-crypto:1.1.0-alpha06")
}
