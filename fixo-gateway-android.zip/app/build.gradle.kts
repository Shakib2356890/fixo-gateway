plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.fixo.gateway"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.fixo.gateway"
        minSdk = 26
        targetSdk = 33
        versionCode = 2
        versionName = "1.1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
    // Pull-to-refresh on the Dashboard tab (WebView of the shop admin).
    implementation("androidx.swiperefreshlayout:swiperefreshlayout:1.1.0")
    // EncryptedSharedPreferences — the HMAC secret lives here, never in code.
    implementation("androidx.security:security-crypto:1.0.0")
}
