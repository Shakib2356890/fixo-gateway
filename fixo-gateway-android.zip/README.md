# Fixo Gateway — Android app

Self-hosted replacement for the UddoktaPay / Paymently phone app.
Runs on the owner's **vivo 1906 (Android 11)**, which holds the MFS SIM
**01328257898**.

## What it does

1. Listens for incoming SMS from **bKash, Nagad, Rocket and Upay**
   (sender IDs `bKash`/`16247`, `Nagad`/`16167`, `Rocket`/`16216`,
   `Upay`/`16268`).
2. Parses each money-IN message for **sender number, amount and
   TrxID**. A message counts as a payment only when all three are
   found — anything less is logged on the phone for review, never guessed.
3. POSTs the payment as JSON to the shop server over HTTPS, signed
   with **HMAC-SHA256** (see `CONTRACT.md` for the exact wire format).
4. Retries failed posts with backoff (1, 2, 5, 15, 30, 60, 120, 360,
   720, 1440 minutes; gives up after 24 h — the SMS is still on the
   phone, so nothing is lost).
5. Shows a status screen: service state, permission state, today's
   counts, last SMS, last successful post, last error, pending queue,
   and the unparseable-message log — plus a recent-payments list
   (newest first, up to 50): method, sender, amount, TrxID, time and
   status (Posted / Pending / Failed), Paymently-style.
6. **No admin dashboard, no WebView (v1.2.0):** the app is a relay
   again. The shop admin lives in the phone browser, not in the app.

## What it does NOT do

* **Never sends money.** It has no send-money code at all.
* **Never reads any other SMS.** Only messages from the four MFS
  sender IDs are considered; everything else is ignored completely
  (not even logged).
* **Never stores credentials.** No password, PIN or API key is in the
  source. The HMAC secret is entered once in the app and kept in
  EncryptedSharedPreferences. The app has no WebView and never opens
  the shop — admin sign-in happens in the phone browser.
* **Never sends the raw SMS body to the server** — only the parsed
  fields plus a SHA-256 hash of the body (used as the idempotency key).

## Permissions — and why each is needed

| Permission | Why |
|---|---|
| `RECEIVE_SMS` | The whole job: catch incoming payment SMS. |
| `INTERNET` | POST payments to the shop server. |
| `ACCESS_NETWORK_STATE` | (Standard; lets the stack check connectivity.) |
| `FOREGROUND_SERVICE` | Keep the retry loop running with a status notification. |
| `RECEIVE_BOOT_COMPLETED` | Restart the service after a reboot. |
| `POST_NOTIFICATIONS` (Android 13+) | Show the persistent status notification. |

`READ_SMS` is **deliberately not requested** — the app does not need
to read the inbox, only to receive new SMS.

## Server contract

Default endpoint: `POST https://fi.xo.je/gateway/verify.php`
(full spec, JSON fields and the HMAC scheme: see **`CONTRACT.md`** —
the PHP side in `~/workspace/gateway/` must implement exactly that).

The server URL is fixed in the app (v1.2.2) — there is no field for
it. The HMAC secret is already stored encrypted on the phone from the
first install, so Settings never asks for it. The secret must match
the one in the server config — if they differ, every post fails with
HTTP 401 and the app keeps retrying.

## Can the APK be built on the Lux VM?

**No — not on this VM.** Checked 2026-11-17 and again 2026-11-18:

* No Java on the PATH (`java`, `gradle`, `sdkmanager` all absent).
* Only ~470 MB RAM free out of 8 GB — the Gradle daemon alone wants
  2 GB (`-Xmx2048m` in `gradle.properties`); it is OOM-killed at startup.
* No cached Gradle dependencies on the VM, so an offline build is
  impossible too, and the proxy blocks the downloads a first build needs.

**Build it in the cloud with GitHub Actions instead** — that is the
supported route, and it needs no computer at all (see
`.github/workflows/build-apk.yml`; full phone-only steps are in
`OWNER-BUILD.md`).

## Build guide — GitHub Actions (phone only, no computer)

1. Create a free GitHub account (github.com) and a new **PUBLIC** repo,
   e.g. `fixo-gateway`.
2. Upload the CONTENTS of this folder into the repo root
   (`settings.gradle.kts`, `build.gradle.kts`, `app/`, `gradle/`,
   `.github/`, etc. at the top level — NOT inside an extra subfolder).
   On the phone: GitHub app or mobile site → repo → "Add file" →
   "Upload files" (upload in a few batches; the whole folder is ~80 KB).
3. The workflow runs automatically on every push. Or open the
   "Actions" tab → "Build Fixo Gateway APK" → "Run workflow".
4. When the run turns green (~3–6 min), open the run, scroll to
   "Artifacts", download `fixo-gateway-apk` (a zip) and unzip it on
   the phone — inside is `app-debug.apk`. Install it on the
   vivo 1906 (see "Install & run" below).

If the code changes later, just upload the changed files again — a new
APK is built automatically on every push.

No secrets are used anywhere in the workflow or the repo. The HMAC
secret is already stored on the phone from the first install — no
secret is entered for an upgrade. (A fresh install shows one secret
field in Settings, once — see step 6 below.)

## Build guide — Android Studio (only if a computer is available)

1. Install **Android Studio** (latest stable) from
   https://developer.android.com/studio — during setup, let it
   install the Android SDK (API 33), SDK Platform-Tools and a JDK
   (Android Studio bundles one; no separate Java install needed).
2. Copy this whole folder to the computer.
3. Open Android Studio → **Open** → select the folder.
   Wait for the Gradle sync to finish (first sync downloads
   dependencies — needs internet, a few minutes).
4. If Android Studio asks to install a missing SDK component, accept.
5. **Build → Build App Bundle(s) / APK(s) → Build APK(s)**.
   The APK appears at
   `app\build\outputs\apk\debug\app-debug.apk`
   (about 3–5 MB). For day-to-day use the debug APK is fine; it is
   signed with the debug key and installs directly on the vivo.
   (A release APK needs a signing key — not required for one phone.)
6. Copy `app-debug.apk` to the vivo 1906 (USB cable, or send it to
   the phone via WhatsApp/Drive — any file transfer works).

If the Gradle sync fails with a version error, the versions used are:
AGP 8.2.2, Kotlin 1.9.22, Gradle 8.5, compileSdk/targetSdk 33,
minSdk 26.

## Install & run on the vivo 1906

1. On the phone: **Settings → Security → allow "Install unknown
   apps"** for the app you use to open the APK (Files / Chrome /
   WhatsApp — whichever you open it with).
2. Open `app-debug.apk` and install **Fixo Gateway**.
3. Open the app. It asks for **SMS permission** — tap **Allow**.
   (Android 13+ also asks for **Notifications** — tap Allow, so the
   status notification can show.)
4. Open the app — the service starts itself. A persistent
   notification appears: "Fixo Gateway — listening for payment
   SMS". **Do not swipe it away** — it is what keeps the app alive.
5. In the phone's **Android Settings → Apps → Fixo Gateway →
   Battery**, choose **Don't optimise**. (Without this, Android may
   kill the app in the background and payments will be delayed.)
6. No setup is needed for an upgrade — the server URL and the
   secret are already on the phone. On a **fresh install** only,
   **Settings** in the app shows one secret field: paste the **HMAC
   secret** (the same secret that is in the server config) and tap
   **Save settings**. The secret is stored encrypted on the phone;
   it is never shown back.
7. Tap **"Send test"**. The server should answer OK — if it fails,
   the toast shows the exact error (wrong secret or no internet).
8. Leave the app installed and the service running. After a reboot,
   the service restarts itself (if "Start the service after a
   reboot" is ticked, which it is by default).
9. **Test with a real payment:** pay ৳10 to 01328257898 from another
   number, then check the app — "Last posted" should show the
   TrxID, and the matching order in the shop admin should turn
   paid. Check the shop admin too: the payment must appear on the
   order exactly once (the server dedupes on the SMS hash).

## Daily operation

* The app opens on the **Payments** tab — the SMS relay status plus
  the recent-payments list. The shop admin is NOT in the app any
  more (v1.2.0 removed the Dashboard tab): open fi.xo.je/admin in
  the phone browser and sign in there (Google sign-in works in
  Chrome).
* The **Payments** tab shows the live status in the header
  (Listening + today's Received / Posted / Pending), a **Send test**
  button, and the recent-payments list (Posted / Pending / Failed).
* If "Pending" stays above 0, the server is down, the secret is
  wrong, or the phone has no internet — the service retries on its
  own every 60 seconds.
* Payment SMS the parser could not read are still logged on the
  phone for review (StatusStore); handle such a payment manually in
  the shop admin — the app never guesses.
* The app does nothing when no payment SMS arrives. It costs no
  money and sends nothing on its own.

## Project layout

```
android/
├── README.md                  this file
├── CONTRACT.md                server ↔ app wire contract (source of truth)
├── settings.gradle.kts
├── build.gradle.kts
├── gradle.properties
├── gradle/wrapper/gradle-wrapper.properties
└── app/
    ├── build.gradle.kts
    ├── proguard-rules.pro
    └── src/main/
        ├── AndroidManifest.xml
        ├── java/com/fixo/gateway/
        │   ├── MainActivity.kt     tab host: Payments (status +
        │   │                       history) + Settings — no WebView
        │   │                       (Dashboard tab removed in v1.2.0)
        │   ├── PaymentHistory.kt   recent-payments list (JSON file)
        │   ├── SmsReceiver.kt      catches incoming SMS (works when closed)
        │   ├── SmsParser.kt        bKash/Nagad/Rocket/Upay formats
        │   ├── PaymentPoster.kt    HTTPS POST + HMAC-SHA256 signing
        │   ├── Payment.kt          payment model + JSON
        │   ├── RetryQueue.kt       durable queue + backoff
        │   ├── GatewayService.kt   foreground service + retry loop
        │   ├── BootReceiver.kt     restart after reboot
        │   ├── SettingsManager.kt  fixed URL + number, secret (encrypted), device id
        │   └── StatusStore.kt      counts + logs for the status screen
        └── res/                    layout, strings, theme, icon
            ├── layout/activity_main.xml        tab host + bottom bar
            ├── layout/layout_tab_payments.xml  Send test + history
            ├── layout/layout_tab_settings.xml  boot switch + version (secret on fresh install only)
            ├── values/colors.xml               Fixo shop palette
            └── drawable/btn_primary.xml etc.   rounded Fixo buttons
```
