# Fixo Gateway — owner build guide (phone only, no computer)

**What this is:** the Android app for the shop's OWN payment gateway.
It runs on your **vivo 1906 (Android 11)**, which holds the MFS SIM
**01328257898**. It listens for bKash / Nagad / Rocket / Upay payment SMS
and posts them (signed) to `https://fi.xo.je/gateway/verify.php` — the
shop then auto-confirms + delivers the order, exactly like UddoktaPay
does today, but with no third party in the middle.

**App name on the phone:** Fixo Gateway. **Package:** `com.fixo.gateway`.

**The app has two tabs** (bottom of the screen):
* **Payments** — the live status in the header (Listening + today's
  Received / Posted / Pending), a **"Send test"** button, and the
  recent-payments list (method, sender, amount, TrxID, time, Posted /
  Pending / Failed).
* **Settings** — just the start-on-boot switch and the version line.
  The server URL and shop number are fixed in the app; the secret is
  never shown or asked for (it is already stored encrypted on the
  phone — a fresh install shows one secret field, once).

> **v1.2.2 — no secret entry, no extra text:** the server URL and
> shop number are fixed in the app, the saved secret is never shown
> or asked for again, and the Payments tab is only the header, the
> Send test button and the history. Install the new APK **over** the
> old app — do NOT uninstall first, or the saved HMAC secret is lost
> and the fresh-install secret field appears.
>
> **v1.2.0 — no Dashboard tab any more:** the shop admin used to
> live inside the app (a WebView tab, v1.1.0). That is REMOVED — the
> app is a Paymently-style relay again. Sign in to the shop admin in
> the phone browser (Chrome), where Google sign-in works. When you
> update to v1.2.0, install the new APK **over** the old app — do NOT
> uninstall first, or the saved HMAC secret must be entered again.

> ✅ **Server is ready:** the shop server already reads the Fixo
> headers (`X-FIXO-Timestamp` / `X-FIXO-Signature`) — live since
> 2026-11-18. The "Send test" step below works now; there is no
> server update left to wait for.

## Part 1 — Build the APK on GitHub (free, from your phone)

You need: a free GitHub account + this folder's contents (Lux sends you
`fixo-gateway-android.zip` — unzip it on the phone with the Files app).

### 1. Create a GitHub account
1. Open Chrome on the phone → **github.com** → **Sign up**.
2. Use email **syncshotter@gmail.com**, pick a username + password.
3. Verify the email (GitHub sends a code to that Gmail — open Gmail,
   copy the code, paste it back on GitHub).

### 2. Create a new PUBLIC repo
1. On GitHub, tap **+** (top right) → **New repository**.
2. Repository name: **`fixo-gateway`**. Choose **Public**.
3. Tap **Create repository**. Leave "Add a README" unticked.

### 3. Upload this folder's files into the repo
1. Unzip `fixo-gateway-android.zip` on the phone (Files app → tap the
   zip → Extract). You get a folder `fixo-gateway-android` with
   `settings.gradle.kts`, `build.gradle.kts`, `app/`, `gradle/`,
   `.github/`, `CONTRACT.md`, `README.md`, `OWNER-BUILD.md`.
2. In the repo, tap **Add file → Upload files**.
3. Upload in a few batches (the file picker can take many files at once,
   but do it folder by folder so nothing is missed):
   - First: `settings.gradle.kts`, `build.gradle.kts`,
     `gradle.properties`, `CONTRACT.md`, `README.md`, `OWNER-BUILD.md`
   - Then the `app/` folder contents (tap into `app/` and upload its
     files + the `src/` subfolders the same way)
   - Then the `gradle/` folder contents (`gradle/wrapper/gradle-wrapper.properties`)
4. **The `.github` folder is hidden** — the phone's file picker usually
   does NOT show it. So create the workflow file by hand instead:
   - In the repo, tap **Add file → Create new file**.
   - In the filename box type exactly:
     `.github/workflows/build-apk.yml`
   - Paste the whole workflow text from the **Appendix** at the bottom
     of this file into the editor, then tap **Commit new file**.
5. Check the repo root shows: `settings.gradle.kts`, `build.gradle.kts`,
   `app/`, `gradle/`, `.github/`, `CONTRACT.md`, `README.md`.

### 4. Run the build
1. The build starts automatically on every upload. Or open the
   **Actions** tab → **Build Fixo Gateway APK** → **Run workflow**.
2. Wait ~3–6 minutes until the run turns **green** (✓). If it turns
   red (✗), open the run, tap the failed step, screenshot the error
   and send it to Lux — do NOT keep re-running it.
3. Open the green run → scroll to **Artifacts** → download
   **`fixo-gateway-apk`** (a zip) → unzip it on the phone.
   Inside is **`app-debug.apk`** (~3–5 MB).

### 5. If the code changes later
Just upload the changed files again — a new APK is built automatically
on every push. No secrets are used anywhere in the workflow or the repo.

## Part 2 — Install & run on the vivo 1906

1. On the phone: **Settings → Security → allow "Install unknown
   apps"** for the app you use to open the APK (Files / Chrome /
   WhatsApp — whichever you open it with).
2. Open `app-debug.apk` and install **Fixo Gateway**.
3. Open the app. It asks for **SMS permission** — tap **Allow**.
   (Android 13+ also asks for **Notifications** — tap Allow, so the
   status notification can show.)
4. Open the app — the service starts itself. A persistent
   notification appears: "Fixo Gateway — listening for payment
   SMS". **Do not swipe it away** — it is what keeps the app alive.
5. In the phone's **Android Settings → Apps → Fixo Gateway →
   Battery**, choose **Don't optimise**. (Without this, Android may
   kill the app in the background and payments will be delayed.)
6. No setup is needed for an upgrade — the server URL and the
   secret are already on the phone. On a **fresh install** only,
   **Settings** in the app shows one secret field: paste the **HMAC
   secret** (the 64-letter/number code inside the server file
   `data/gateway-config.php` — open that file in the InfinityFree
   File Manager on your phone and copy the code from it, then paste
   it here. Lux never sends the secret in chat. It must match the
   server exactly — if it differs, every post fails with HTTP 401
   and the app keeps retrying) and tap **Save settings**. The secret
   is stored encrypted on the phone; it is never shown back. **Never
   share it with anyone.**
7. Tap **"Send test"** (top of the **Payments** tab).
   - ✅ Toast **"Test post accepted by the server."** = the app talks
     to the server and the secret is right. (The test is answered 200
     and ignored by the server — no order, no delivery, nothing logged
     as a payment. The toast is the proof.)
   - ❌ Toast with an error = read it: "server answered HTTP 401"
     means the secret is wrong or the server still has the old
     headers; "no internet" / timeout means the phone is offline.
     Fix it, then **"Send test"** again.
8. Leave the app installed and the service running. After a reboot,
   the service restarts itself (if "Start the service after a reboot"
   is ticked, which it is by default).

## Shop admin — use the phone browser (no Dashboard tab any more)

* The shop admin (`fi.xo.je/admin`) is NOT inside the app since
  v1.2.0 — the Dashboard tab was removed. Open it in Chrome on the
  phone and sign in there: **"Continue with Google" works in the
  browser** (it never worked inside the app — Google blocks sign-in
  inside any app's built-in browser, which is why the tab is gone).
* To check orders and confirm payments, use the browser admin; the
  app's **Payments** tab shows the relay status and the
  recent-payments list.

## Part 3 — Test with a real payment (tiny amount only)

1. Make a small test order on fi.xo.je (cheapest product, Canva Pro ৳49)
   — or just pay **৳10** by bKash to **01328257898** from another number.
2. Check the app, **Payments** tab: **"Last posted"** should show the TrxID within a
   few seconds, and **"Today — posted"** should go up by 1.
3. Check the shop admin in the phone browser: the payment must appear exactly once (the
   server dedupes on the SMS hash). If the payment matched a pending
   order, that order turns paid and the access is delivered.
4. If **"Pending"** stays above 0, check **"Last error"** — usually the
   server is down, the secret is wrong, or the phone has no internet.
   Tap **"Retry pending now"** after fixing it.

## Daily operation

* The **Payments** tab is the SMS relay status: today's received /
  posted / failed counts, pending queue, last error, and the
  recent-payments list.
* Check orders and confirm payments in the shop admin in the phone
  browser — not in the app (no Dashboard tab since v1.2.0).
* "Unparseable MFS messages" lists payment SMS the parser could not
  read (missing amount/sender/TrxID). Read one, tell Lux, and handle
  that payment manually in the shop admin — the app never guesses.
* **Keep the UddoktaPay/Paymently app installed and live** until this
  gateway passes the full test plan. Both apps can run side by side
  (they post to different servers). Only switch the shop over when
  Lux says the tests pass.

## What the app does NOT do

* **Never sends money.** It has no send-money code at all.
* **Never reads any other SMS.** Only messages from bKash (`bKash` /
  `16247`), Nagad (`Nagad` / `16167`), Rocket (`Rocket` / `16216`) and
  Upay (`Upay` / `16268`) are considered; everything else is ignored
  completely (not even logged).
* **Never stores credentials.** No password, PIN or API key is in the
  app. The HMAC secret is entered once and kept encrypted on the phone.
* **Never sends the raw SMS body to the server** — only the parsed
  fields (provider, sender, amount, TrxID) plus a SHA-256 hash of the
  body (used as the idempotency key).

## Appendix — workflow file (paste this when creating `.github/workflows/build-apk.yml`)

```yaml
# Fixo Gateway — build the debug APK in the cloud (GitHub Actions)
#
# Why this exists: the APK cannot be built on the Lux VM (no JDK, and the
# Gradle daemon is OOM-killed at startup — only ~470 MB RAM is free), and
# Sir has no computer, so there is no Windows PC to build on either.
# GitHub's free runner builds it instead. No secrets are used anywhere
# in this file or in the repo.
#
# How Sir uses it (from his phone):
#   1. Create a free GitHub account (github.com) and a new PUBLIC repo,
#      e.g. "fixo-gateway".
#   2. Upload the CONTENTS of this folder into the repo root
#      (settings.gradle.kts, build.gradle.kts, app/, gradle/, etc. at
#      the top level — NOT inside an extra subfolder).
#      On the phone: GitHub app or mobile site -> repo -> "Add file" ->
#      "Upload files" (upload in a few batches; the whole folder is ~80 KB).
#   3. The workflow runs automatically on every push. Or open the
#      "Actions" tab -> "Build Fixo Gateway APK" -> "Run workflow".
#   4. When the run turns green (~3-6 min), open the run, scroll to
#      "Artifacts", download "fixo-gateway-apk" (a zip) and unzip it
#      on the phone — inside is app-debug.apk. Install it on the
#      vivo 1906 (see the install steps above).
#
# If the code changes later, just upload the changed files again — a new
# APK is built automatically on every push.

name: Build Fixo Gateway APK

on:
  push:
  workflow_dispatch:

jobs:
  build:
    runs-on: ubuntu-latest

    steps:
      - name: Check out code
        uses: actions/checkout@v4

      - name: Set up JDK 17
        uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: '17'

      - name: Set up Android SDK
        uses: android-actions/setup-android@v3

      - name: Install SDK packages and accept licenses
        run: |
          yes | "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" --licenses
          "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" "platforms;android-33" "build-tools;33.0.0"

      - name: Set up Gradle 8.5
        uses: gradle/actions/setup-gradle@v3
        with:
          gradle-version: '8.5'

      - name: Build debug APK
        run: gradle :app:assembleDebug --no-daemon --stacktrace

      - name: Upload APK
        uses: actions/upload-artifact@v4
        with:
          name: fixo-gateway-apk
          path: app/build/outputs/apk/debug/app-debug.apk
          if-no-files-found: error
```
